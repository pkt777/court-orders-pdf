<?php
/**
 * Plugin Name: Court Listener
 * Description: Automated Indian court judgment fetcher — Supreme Court of India (daily cause list) and Mumbai High Court (eSCR/BHC). Downloads PDFs, archives to GitHub, generates Claude AI summaries, creates WordPress posts. Extensible for all High Courts.
 * Version:     1.0.0
 * Author:      WPPluginsForYou
 * License:     GPL v2 or later
 *
 * ════════════════════════════════════════════════════════════════
 *  SUPREME COURT PIPELINE
 * ════════════════════════════════════════════════════════════════
 *  1. Fetch daily cause list PDF → api.sci.gov.in/jonew/cl/YYYY-MM-DD/M_J.pdf
 *  2. Extract text (pdftotext → regex fallback)
 *  3. Parse tax case blocks (diary number, case number, party names)
 *  4. Find judgment PDF via openCaseJudgment API (diary number → PDF path)
 *  5. Download judgment PDF
 *  6. Upload to GitHub: SC/YYYY/MM/Category/Title.pdf
 *  7. Claude AI summary (Haiku)
 *  8. WordPress post via raw $wpdb (RevTheme-safe)
 *
 * ════════════════════════════════════════════════════════════════
 *  MUMBAI HIGH COURT PIPELINE
 * ════════════════════════════════════════════════════════════════
 *  1. GET https://bombayhighcourt.nic.in/recentorderjudgment.php
 *     (no POST, no CAPTCHA, no session — plain HTML table of all recent judgments)
 *  2. Scrape result links → generatenewauth.php?bhcpar=BASE64
 *  3. Decode BASE64 → fname, uploaddt, ncitation (e.g. 2026:BHC-AS:9214-DB)
 *  4. Download PDF from generatenewauth.php URL
 *  5. Upload to GitHub: MHC/YYYY/MM/Category/Title.pdf
 *  6. Claude AI summary
 *  7. WordPress post via raw $wpdb
 *
 * ════════════════════════════════════════════════════════════════
 *  GITHUB FOLDER LAYOUT
 * ════════════════════════════════════════════════════════════════
 *  {repo}/
 *  ├── SC/   Supreme Court of India
 *  ├── MHC/  Mumbai High Court
 *  ├── DHC/  Delhi HC  (future)
 *  └── CHC/  Calcutta HC (future)
 *
 *  Each court: YYYY/MM/Tax-Category/Case-Title.pdf
 *
 * ════════════════════════════════════════════════════════════════
 *  KEY TECHNICAL DECISIONS
 * ════════════════════════════════════════════════════════════════
 *  • All WordPress post writes use raw $wpdb (no wp_insert_post) — RevTheme-safe
 *  • Timeout probe + 30-min transient block on SCI timeout/DB errors
 *  • BHC bhcpar decoded to extract ncitation and actual PDF filename
 *  • Shared GitHub / Claude settings; per-court category + schedule settings
 *  • Two DB tables: wp_cl_sc_cases, wp_cl_mhc_cases (same schema)
 *  • One shared log table: wp_cl_logs (court column: SC / MHC)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Constants ────────────────────────────────────────────────────────────────
define( 'CL_VERSION',    '1.0.0' );
define( 'CL_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CL_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CL_PLUGIN_FILE', __FILE__ );

// ── Tax keywords (shared across courts, upper-case) ──────────────────────────
define( 'CL_TAX_KEYWORDS', serialize( array(
    'INCOME TAX', 'COMMISSIONER OF INCOME TAX', 'CIT', 'PCIT', 'ACIT', 'DCIT',
    'INCOME TAX OFFICER', 'ITO', 'ASSESSMENT UNIT', 'CENTRAL CIRCLE',
    'ASSESSING OFFICER', 'CBDT', 'CENTRAL BOARD OF DIRECT TAXES',
    'DIRECTOR OF INCOME TAX', 'DIT', 'TRANSFER PRICING',
    'CGST', 'SGST', 'IGST', 'GST', 'GOODS AND SERVICES TAX',
    'COMMISSIONER OF GST', 'COMMISSIONER CGST', 'CHIEF COMMISSIONER OF CGST',
    'CUSTOMS', 'COMMISSIONER OF CUSTOMS', 'CUSTOMS DUTY',
    'SERVICE TAX', 'CENTRAL EXCISE', 'CENVAT',
    'FEMA', 'ENFORCEMENT DIRECTORATE', 'MONEY LAUNDERING',
) ) );

// ── Tax category map (keyword → category label) ──────────────────────────────
define( 'CL_CATEGORY_MAP', serialize( array(
    'Income Tax'  => array( 'INCOME TAX', 'CIT', 'PCIT', 'ACIT', 'DCIT', 'ITO', 'CBDT',
                            'DIRECTOR OF INCOME TAX', 'ASSESSMENT UNIT', 'CENTRAL CIRCLE',
                            'TRANSFER PRICING', 'ASSESSING OFFICER' ),
    'GST'         => array( 'CGST', 'SGST', 'IGST', 'GST', 'GOODS AND SERVICES TAX',
                            'COMMISSIONER OF GST', 'COMMISSIONER CGST' ),
    'Customs'     => array( 'CUSTOMS', 'CUSTOMS DUTY', 'ANTI-DUMPING' ),
    'Service Tax' => array( 'SERVICE TAX', 'TAXABLE SERVICE' ),
    'Excise'      => array( 'CENTRAL EXCISE', 'CENVAT', 'EXCISE DUTY' ),
    'FEMA/PMLA'   => array( 'FEMA', 'ENFORCEMENT DIRECTORATE', 'MONEY LAUNDERING', 'FOREIGN EXCHANGE' ),
) ) );

// ── Cron schedules (must register before plugins_loaded) ─────────────────────
add_filter( 'cron_schedules', function( $s ) {
    if ( ! isset( $s['daily'] ) ) {
        $s['daily'] = array( 'interval' => DAY_IN_SECONDS, 'display' => 'Once Daily' );
    }
    return $s;
} );

// ── Activation hook — must be at file level, not inside plugins_loaded ───────
register_activation_hook( __FILE__, function() {
    Court_Listener::create_tables();
    Court_Listener::schedule_crons();
} );

register_deactivation_hook( __FILE__, function() {
    wp_clear_scheduled_hook( 'cl_sc_daily_scrape' );
    wp_clear_scheduled_hook( 'cl_mhc_daily_scrape' );
} );

// ── Bootstrap ────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function() {
    Court_Listener::get_instance();
} );

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PLUGIN CLASS
// ══════════════════════════════════════════════════════════════════════════════
class Court_Listener {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Note: activation/deactivation hooks registered at file level above
        add_action( 'init',       array( $this, 'register_post_types' ) );
        add_action( 'admin_menu', array( $this, 'add_menus' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_init', array( $this, 'maybe_create_tables' ) );

        // Cron hooks
        add_action( 'cl_sc_daily_scrape',  array( $this, 'run_sc_scrape' ) );
        add_action( 'cl_mhc_daily_scrape', array( $this, 'run_mhc_scrape' ) );

        // AJAX
        add_action( 'wp_ajax_cl_sc_run',          array( $this, 'ajax_sc_run' ) );
        add_action( 'wp_ajax_cl_sc_test',         array( $this, 'ajax_sc_test' ) );
        add_action( 'wp_ajax_cl_mhc_run',         array( $this, 'ajax_mhc_run' ) );
        add_action( 'wp_ajax_cl_mhc_test',        array( $this, 'ajax_mhc_test' ) );
        add_action( 'wp_ajax_cl_mhc_fetch',       array( $this, 'ajax_mhc_fetch' ) );
        add_action( 'wp_ajax_cl_mhc_process_one', array( $this, 'ajax_mhc_process_one' ) );
        add_action( 'wp_ajax_cl_sc_fetch',        array( $this, 'ajax_sc_fetch' ) );
        add_action( 'wp_ajax_cl_sc_process_one',  array( $this, 'ajax_sc_process_one' ) );
        add_action( 'wp_ajax_cl_test_github',   array( $this, 'ajax_test_github' ) );
        add_action( 'wp_ajax_cl_clear_logs',    array( $this, 'ajax_clear_logs' ) );

        // Shortcodes
        add_shortcode( 'court_listener',     array( $this, 'shortcode_all' ) );
        add_shortcode( 'court_listener_sc',  array( $this, 'shortcode_sc' ) );
        add_shortcode( 'court_listener_mhc', array( $this, 'shortcode_mhc' ) );
    }

    // ── ACTIVATION ────────────────────────────────────────────────────────────
    // Static so it can be called from the file-level activation hook
    public static function create_tables() {
        global $wpdb;
        $cs = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $case_cols = "
            id           bigint(20)   NOT NULL AUTO_INCREMENT,
            case_hash    varchar(64)  NOT NULL,
            case_title   varchar(600) NOT NULL,
            case_number  varchar(120) DEFAULT '',
            diary_number varchar(60)  DEFAULT '',
            case_date    date         DEFAULT NULL,
            pdf_url      text         DEFAULT NULL,
            github_url   text         DEFAULT NULL,
            post_id      bigint(20)   DEFAULT NULL,
            tax_category varchar(100) DEFAULT 'Income Tax',
            cl_date      date         DEFAULT NULL,
            status       varchar(30)  DEFAULT 'pending',
            created_at   datetime     DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY case_hash (case_hash)
        ";

        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_sc_cases  ({$case_cols}) {$cs};" );
        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_mhc_cases ({$case_cols}) {$cs};" );

        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_logs (
            id        bigint(20)   NOT NULL AUTO_INCREMENT,
            court     varchar(10)  DEFAULT 'SC',
            level     varchar(10)  DEFAULT 'info',
            context   varchar(100) DEFAULT '',
            message   text,
            logged_at datetime     DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$cs};" );

        update_option( 'cl_tables_created', CL_VERSION );
    }

    public static function schedule_crons() {
        if ( ! wp_next_scheduled( 'cl_sc_daily_scrape' ) ) {
            $next = strtotime( 'today 05:00:00' );
            if ( $next < time() ) $next += DAY_IN_SECONDS;
            wp_schedule_event( $next, 'daily', 'cl_sc_daily_scrape' );
        }
        if ( ! wp_next_scheduled( 'cl_mhc_daily_scrape' ) ) {
            $next = strtotime( 'today 05:30:00' );
            if ( $next < time() ) $next += DAY_IN_SECONDS;
            wp_schedule_event( $next, 'daily', 'cl_mhc_daily_scrape' );
        }
    }

    // Runs on admin_init — creates tables if missing (handles upgrades/re-installs)
    public function maybe_create_tables() {
        if ( get_option('cl_tables_created') !== CL_VERSION ) {
            self::create_tables();
        }
    }

    public function activate() {
        self::create_tables();
        self::schedule_crons();
        $this->register_post_types();
        flush_rewrite_rules();
    }

    // keep old activate body for reference but delegate to statics:
    private function activate_old() {
        global $wpdb;
        $cs = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Shared case schema (used by both SC and MHC tables)
        $case_cols = "
            id           bigint(20)   NOT NULL AUTO_INCREMENT,
            case_hash    varchar(64)  NOT NULL,
            case_title   varchar(600) NOT NULL,
            case_number  varchar(120) DEFAULT '',
            diary_number varchar(60)  DEFAULT '',
            case_date    date         DEFAULT NULL,
            pdf_url      text         DEFAULT NULL,
            github_url   text         DEFAULT NULL,
            post_id      bigint(20)   DEFAULT NULL,
            tax_category varchar(100) DEFAULT 'Income Tax',
            cl_date      date         DEFAULT NULL,
            status       varchar(30)  DEFAULT 'pending',
            created_at   datetime     DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY case_hash (case_hash)
        ";

        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_sc_cases  ({$case_cols}) {$cs};" );
        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_mhc_cases ({$case_cols}) {$cs};" );

        dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cl_logs (
            id        bigint(20)   NOT NULL AUTO_INCREMENT,
            court     varchar(10)  DEFAULT 'SC',
            level     varchar(10)  DEFAULT 'info',
            context   varchar(100) DEFAULT '',
            message   text,
            logged_at datetime     DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) {$cs};" );

        $this->register_post_types();
        flush_rewrite_rules();

        // Schedule SC cron: 10:30am IST = 5:00am UTC
        if ( ! wp_next_scheduled( 'cl_sc_daily_scrape' ) ) {
            $next = strtotime( 'today 05:00:00' );
            if ( $next < time() ) $next += DAY_IN_SECONDS;
            wp_schedule_event( $next, 'daily', 'cl_sc_daily_scrape' );
        }
        // Schedule MHC cron: 11:00am IST = 5:30am UTC
        if ( ! wp_next_scheduled( 'cl_mhc_daily_scrape' ) ) {
            $next = strtotime( 'today 05:30:00' );
            if ( $next < time() ) $next += DAY_IN_SECONDS;
            wp_schedule_event( $next, 'daily', 'cl_mhc_daily_scrape' );
        }
    }

    public function deactivate() {
        wp_clear_scheduled_hook( 'cl_sc_daily_scrape' );
        wp_clear_scheduled_hook( 'cl_mhc_daily_scrape' );
    }

    // ── POST TYPES & TAXONOMIES ───────────────────────────────────────────────
    public function register_post_types() {
        // Shared post type for all courts
        register_post_type( 'cl_judgment', array(
            'labels'       => array( 'name' => 'Court Judgments', 'singular_name' => 'Court Judgment' ),
            'public'       => true,
            'has_archive'  => true,
            'menu_icon'    => 'dashicons-portfolio',
            'supports'     => array( 'title', 'editor', 'excerpt', 'custom-fields' ),
            'show_in_rest' => true,
            'rewrite'      => array( 'slug' => 'court-judgments' ),
        ) );

        register_taxonomy( 'cl_court', 'cl_judgment', array(
            'label'        => 'Court',
            'hierarchical' => true,
            'show_in_rest' => true,
        ) );

        register_taxonomy( 'cl_tax_area', 'cl_judgment', array(
            'label'        => 'Tax Area',
            'hierarchical' => true,
            'show_in_rest' => true,
        ) );

        // Seed terms
        foreach ( array( 'Supreme Court of India', 'Mumbai High Court' ) as $court ) {
            if ( ! term_exists( $court, 'cl_court' ) ) wp_insert_term( $court, 'cl_court' );
        }
        foreach ( array_keys( unserialize( CL_CATEGORY_MAP ) ) as $cat ) {
            if ( ! term_exists( $cat, 'cl_tax_area' ) ) wp_insert_term( $cat, 'cl_tax_area' );
        }
    }

    // ── SETTINGS ──────────────────────────────────────────────────────────────
    public function register_settings() {
        $opts = array(
            // Shared
            'cl_github_token', 'cl_github_owner', 'cl_github_repo',
            'cl_claude_key', 'cl_auto_publish', 'cl_max_per_run',
            // SC
            'cl_sc_enabled', 'cl_sc_enabled_categories', 'cl_sc_lookback_days',
            // MHC
            'cl_mhc_enabled', 'cl_mhc_enabled_categories', 'cl_mhc_lookback_days',
            // Proxy (for NIC IP block bypass)
            'cl_scraperapi_key', 'cl_proxy_url',
        );
        foreach ( $opts as $opt ) register_setting( 'cl_settings_group', $opt );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ADMIN MENUS
    // ══════════════════════════════════════════════════════════════════════════
    public function add_menus() {
        add_menu_page(
            'Court Listener', 'Court Listener', 'manage_options',
            'court-listener', array( $this, 'page_dashboard' ),
            'dashicons-portfolio', 30
        );
        add_submenu_page( 'court-listener', 'Dashboard',         'Dashboard',         'manage_options', 'court-listener',     array( $this, 'page_dashboard' ) );
        add_submenu_page( 'court-listener', 'Supreme Court',     'Supreme Court',     'manage_options', 'cl-supreme-court',   array( $this, 'page_sc' ) );
        add_submenu_page( 'court-listener', 'Mumbai High Court', 'Mumbai High Court', 'manage_options', 'cl-mumbai-hc',       array( $this, 'page_mhc' ) );
        add_submenu_page( 'court-listener', 'Settings',          'Settings',          'manage_options', 'cl-settings',        array( $this, 'page_settings' ) );
        add_submenu_page( 'court-listener', 'Logs',              'Logs',              'manage_options', 'cl-logs',            array( $this, 'page_logs' ) );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SHARED ADMIN STYLES
    // ══════════════════════════════════════════════════════════════════════════
    private function admin_styles() {
        return '
        <style>
        .cl-wrap{max-width:1100px}
        .cl-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin:18px 0}
        .cl-card{background:#fff;padding:16px;border-left:4px solid #0073aa;box-shadow:0 1px 3px rgba(0,0,0,.08);border-radius:4px}
        .cl-card h3{margin:0 0 6px;color:#666;font-size:11px;text-transform:uppercase;letter-spacing:.5px}
        .cl-card .num{font-size:28px;font-weight:700;color:#0073aa}
        .cl-box{background:#fff;padding:18px;margin:16px 0;box-shadow:0 1px 3px rgba(0,0,0,.08);border-radius:4px}
        .cl-box h2{margin-top:0}
        .cl-badge{display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;text-transform:uppercase}
        .cl-badge.sc{background:#e6f0fa;color:#0056b3}
        .cl-badge.mhc{background:#fde8e0;color:#b94a2c}
        .cl-info{background:#e7f3fe;border-left:4px solid #0073aa;padding:14px 18px;border-radius:0 4px 4px 0;margin:16px 0;font-size:13px}
        .cl-info ol{margin:8px 0 0 16px}.cl-info li{margin:4px 0}
        #cl-status{margin-top:12px;font-weight:600;white-space:pre-wrap;font-family:monospace;font-size:13px;line-height:1.6}
        </style>';
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PAGE: DASHBOARD
    // ══════════════════════════════════════════════════════════════════════════
    public function page_dashboard() {
        global $wpdb;
        $sc  = $wpdb->prefix . 'cl_sc_cases';
        $mhc = $wpdb->prefix . 'cl_mhc_cases';

        $sc_next  = wp_next_scheduled( 'cl_sc_daily_scrape' );
        $mhc_next = wp_next_scheduled( 'cl_mhc_daily_scrape' );

        $stats = array(
            'sc_total'     => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$sc}  WHERE status='completed'"),
            'sc_today'     => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$sc}  WHERE DATE(created_at)=CURDATE()"),
            'mhc_total'    => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$mhc} WHERE status='completed'"),
            'mhc_today'    => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$mhc} WHERE DATE(created_at)=CURDATE()"),
            'total_posts'  => (int)($wp_count = wp_count_posts('cl_judgment'))->publish + (int)$wp_count->draft,
        );
        ?>
        <div class="wrap cl-wrap">
        <?php echo $this->admin_styles(); ?>
        <h1>⚖️ Court Listener <small style="font-size:13px;color:#888;font-weight:400">v<?php echo CL_VERSION ?></small></h1>
        <p style="color:#666;margin-top:-8px">Automated Indian court judgment tracker — Supreme Court + Mumbai High Court</p>

        <div class="cl-grid">
            <?php foreach ( array(
                'sc_total'    => '🏛️ SC Total',
                'sc_today'    => '🏛️ SC Today',
                'mhc_total'   => '⚖️ MHC Total',
                'mhc_today'   => '⚖️ MHC Today',
                'total_posts' => '📝 WP Posts',
            ) as $k => $label ) : ?>
            <div class="cl-card"><h3><?php echo $label ?></h3><div class="num"><?php echo $stats[$k] ?></div></div>
            <?php endforeach ?>
        </div>

        <?php
        // Check if tables exist
        $logs_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}cl_logs'") === $wpdb->prefix.'cl_logs';
        $sc_exists   = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}cl_sc_cases'") === $wpdb->prefix.'cl_sc_cases';
        $mhc_exists  = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}cl_mhc_cases'") === $wpdb->prefix.'cl_mhc_cases';
        if (!$logs_exists || !$sc_exists || !$mhc_exists):
        ?>
        <div class="notice notice-error" style="padding:15px">
            <strong>⚠️ Database tables missing!</strong>
            <p>Tables not found: <?php echo implode(', ', array_filter([!$logs_exists?'cl_logs':null, !$sc_exists?'cl_sc_cases':null, !$mhc_exists?'cl_mhc_cases':null])) ?></p>
            <p><a href="<?php echo admin_url('admin.php?page=court-listener&create_tables=1&_wpnonce='.wp_create_nonce('cl_create_tables')) ?>" class="button button-primary">🔧 Create Tables Now</a></p>
        </div>
        <?php endif ?>

        <?php
        // Handle manual table creation
        if (isset($_GET['create_tables']) && wp_verify_nonce($_GET['_wpnonce']??'','cl_create_tables') && current_user_can('manage_options')) {
            Court_Listener::create_tables();
            echo '<div class="notice notice-success"><p>✅ Tables created successfully!</p></div>';
        }
        ?>

        <div class="cl-box">
            <h2>⏰ Scheduled Runs</h2>
            <table class="widefat" style="width:auto;font-size:13px">
                <tr><td style="padding:6px 16px 6px 0"><span class="cl-badge sc">SC</span></td>
                    <td><?php echo $sc_next ? date('D d M Y, H:i:s', $sc_next).' UTC' : '<em>not scheduled</em>' ?></td></tr>
                <tr><td style="padding:6px 16px 6px 0"><span class="cl-badge mhc">MHC</span></td>
                    <td><?php echo $mhc_next ? date('D d M Y, H:i:s', $mhc_next).' UTC' : '<em>not scheduled</em>' ?></td></tr>
            </table>
        </div>

        <?php
        // Recent from both courts combined
        $sc_rows  = $wpdb->get_results("SELECT *,'SC' AS court FROM {$sc}  ORDER BY created_at DESC LIMIT 8");
        $mhc_rows = $wpdb->get_results("SELECT *,'MHC' AS court FROM {$mhc} ORDER BY created_at DESC LIMIT 8");
        $all = array_merge($sc_rows, $mhc_rows);
        usort($all, fn($a,$b) => strcmp($b->created_at, $a->created_at));
        $recent = array_slice($all, 0, 15);
        if ( $recent ) :
        ?>
        <div class="cl-box">
            <h2>📋 Recent Judgments (All Courts)</h2>
            <table class="wp-list-table widefat striped" style="font-size:13px">
                <thead><tr><th>Court</th><th>Case Title</th><th>Category</th><th>Date</th><th>Status</th><th>Post</th></tr></thead>
                <tbody>
                <?php foreach ($recent as $r):
                    $colors = array('completed'=>'green','pending'=>'#888','no_pdf'=>'orange','failed'=>'red','download_failed'=>'red','github_failed'=>'darkorange','post_failed'=>'orange');
                    $c = $colors[$r->status] ?? '#666';
                ?>
                <tr>
                    <td><span class="cl-badge <?php echo strtolower($r->court) ?>"><?php echo esc_html($r->court) ?></span></td>
                    <td><?php echo esc_html(substr($r->case_title,0,65)) ?>…</td>
                    <td><?php echo esc_html($r->tax_category) ?></td>
                    <td style="font-size:11px"><?php echo esc_html($r->cl_date) ?></td>
                    <td><span style="color:<?php echo $c ?>;font-weight:600"><?php echo esc_html($r->status) ?></span></td>
                    <td><?php if($r->post_id): ?><a href="<?php echo get_edit_post_link($r->post_id) ?>">Edit</a><?php endif ?></td>
                </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php endif ?>
        </div>
        <?php
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PAGE: SUPREME COURT
    // ══════════════════════════════════════════════════════════════════════════
    public function page_sc() {
        global $wpdb;
        $sc = $wpdb->prefix . 'cl_sc_cases';
        $rows = $wpdb->get_results("SELECT * FROM {$sc} ORDER BY created_at DESC LIMIT 20");
        $next = wp_next_scheduled('cl_sc_daily_scrape');
        $enabled = get_option('cl_sc_enabled','1');
        ?>
        <div class="wrap cl-wrap">
        <?php echo $this->admin_styles(); ?>
        <h1>🏛️ Supreme Court of India</h1>
        <p style="color:#666;margin-top:-8px">Source: Daily Cause List PDF → <code>api.sci.gov.in</code> → JUDIS judgment API → GitHub → Claude summary</p>

        <?php if (!$enabled || $enabled==='0'): ?>
        <div class="notice notice-warning"><p>⚠️ Supreme Court scraper is <strong>disabled</strong>. Enable it in <a href="<?php echo admin_url('admin.php?page=cl-settings') ?>">Settings</a>.</p></div>
        <?php endif ?>

        <div class="cl-info">
            <strong>How it works:</strong>
            <ol>
                <li>Fetches daily cause list PDF from <code>api.sci.gov.in/jonew/cl/YYYY-MM-DD/M_J.pdf</code></li>
                <li>Extracts text and parses tax case blocks (Income Tax / GST / Customs / Service Tax / Excise / FEMA)</li>
                <li>Queries <code>openCaseJudgment/{diary}/{year}</code> API to find judgment PDF URL</li>
                <li>Downloads PDF → uploads to GitHub under <code>SC/YYYY/MM/Category/</code></li>
                <li>Sends first 3000 chars to Claude (Haiku) for structured legal summary</li>
                <li>Creates WordPress post via <code>$wpdb</code> (RevTheme-safe, no <code>wp_insert_post</code>)</li>
            </ol>
        </div>

        <div class="cl-box">
            <h2>⚡ Quick Actions</h2>
            <button id="cl-sc-run" class="button button-primary button-large">🔄 Run SC Scrape Now</button>&nbsp;
            <button id="cl-sc-test" class="button button-large">🧪 Test Cause List Fetch</button>
            <div id="cl-status"></div>
            <?php if ($next): ?>
            <p style="margin-top:10px;color:#666;font-size:13px">⏰ Next scheduled run: <strong><?php echo date('D d M Y, H:i', $next) ?> UTC</strong> (approx 10:30am IST)</p>
            <?php endif ?>
        </div>

        <?php if ($rows): ?>
        <div class="cl-box">
            <h2>📋 Recent SC Cases</h2>
            <table class="wp-list-table widefat striped" style="font-size:13px">
                <thead><tr><th>Case Title</th><th>Case No.</th><th>Diary No.</th><th>Category</th><th>CL Date</th><th>Status</th><th>Post</th></tr></thead>
                <tbody>
                <?php foreach($rows as $r):
                    $colors=array('completed'=>'green','pending'=>'#888','no_pdf'=>'orange','failed'=>'red','download_failed'=>'red','github_failed'=>'darkorange','post_failed'=>'orange');
                    $c=$colors[$r->status]??'#666';
                ?>
                <tr>
                    <td><?php echo esc_html(substr($r->case_title,0,65)) ?>…</td>
                    <td style="font-size:11px"><?php echo esc_html($r->case_number) ?></td>
                    <td style="font-size:11px"><?php echo esc_html($r->diary_number) ?></td>
                    <td><?php echo esc_html($r->tax_category) ?></td>
                    <td><?php echo esc_html($r->cl_date) ?></td>
                    <td><span style="color:<?php echo $c ?>;font-weight:600"><?php echo esc_html($r->status) ?></span></td>
                    <td><?php if($r->post_id): ?><a href="<?php echo get_edit_post_link($r->post_id) ?>">Edit</a><?php endif ?></td>
                </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php endif ?>
        </div>

        <script>
        jQuery(function($){
            var n='<?php echo wp_create_nonce("cl_nonce") ?>';

            $('#cl-sc-run').on('click', function(){
                if(!confirm("Fetch today's SC cause list and process tax cases?")) return;
                var btn=$(this), st=$('#cl-status');
                btn.prop('disabled',true).text('⏳ Step 1: Fetching cause list…');
                st.html('Fetching daily cause list from api.sci.gov.in via ScraperAPI…<br><small>This takes ~10 seconds.</small>');

                $.post(ajaxurl, {action:'cl_sc_fetch', nonce:n}, function(r){
                    if(!r.success){
                        btn.prop('disabled',false).text('🔄 Run SC Scrape Now');
                        st.html('❌ ' + r.data);
                        return;
                    }
                    var total = r.data.total;
                    var qkey  = r.data.queue_key;
                    st.html('✅ ' + r.data.message + '<br><div id="cl-progress" style="margin-top:8px;font-family:monospace;font-size:12px;background:#f5f5f5;padding:10px;border-radius:4px;max-height:200px;overflow-y:auto"></div>');
                    btn.text('⏳ Processing 1 of ' + total + '…');

                    function processNext(done) {
                        if(done >= <?php echo (int)get_option('cl_max_per_run',5) ?>) {
                            btn.prop('disabled',false).text('🔄 Run SC Scrape Now');
                            $('#cl-progress').append('<br>✅ Done — max per run reached.');
                            return;
                        }
                        $.post(ajaxurl, {action:'cl_sc_process_one', nonce:n, queue_key:qkey, done:done}, function(r2){
                            if(!r2.success){ btn.prop('disabled',false).text('🔄 Run SC Scrape Now'); st.html('❌ '+r2.data); return; }
                            var d = r2.data;
                            $('#cl-progress').append(d.message + '<br>');
                            $('#cl-progress').scrollTop($('#cl-progress')[0].scrollHeight);
                            if(d.status==='done'||d.status==='limit_reached'){
                                btn.prop('disabled',false).text('🔄 Run SC Scrape Now');
                                $('#cl-progress').append('<br>✅ All done! <a href="edit.php?post_type=cl_judgment">View posts →</a>');
                                return;
                            }
                            if(d.continue){ btn.text('⏳ Processing '+(d.done+1)+' of '+total+'…'); setTimeout(function(){ processNext(d.done); }, 500); }
                            else { btn.prop('disabled',false).text('🔄 Run SC Scrape Now'); $('#cl-progress').append('<br>✅ Complete!'); }
                        }).fail(function(xhr){ btn.prop('disabled',false).text('🔄 Run SC Scrape Now'); st.html('❌ Request failed (HTTP '+xhr.status+').'); });
                    }
                    processNext(0);
                }).fail(function(xhr){ btn.prop('disabled',false).text('🔄 Run SC Scrape Now'); st.html('❌ Fetch failed (HTTP '+xhr.status+').'); });
            });

            $('#cl-sc-test').on('click',function(){
                var btn=$(this),st=$('#cl-status');
                btn.prop('disabled',true).text('Testing…');
                st.html('Probing api.sci.gov.in…');
                $.post(ajaxurl,{action:'cl_sc_test',nonce:n},function(r){
                    btn.prop('disabled',false).text('🧪 Test Cause List Fetch');
                    st.html((r.success?'✅ ':'❌ ')+r.data);
                }).fail(function(){ btn.prop('disabled',false).text('🧪 Test Cause List Fetch'); st.html('❌ Request failed.'); });
            });
        });
        </script>
        <?php
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PAGE: MUMBAI HIGH COURT
    // ══════════════════════════════════════════════════════════════════════════
    public function page_mhc() {
        global $wpdb;
        $mhc = $wpdb->prefix . 'cl_mhc_cases';
        $rows = $wpdb->get_results("SELECT * FROM {$mhc} ORDER BY created_at DESC LIMIT 20");
        $next = wp_next_scheduled('cl_mhc_daily_scrape');
        $enabled = get_option('cl_mhc_enabled','1');
        ?>
        <div class="wrap cl-wrap">
        <?php echo $this->admin_styles(); ?>
        <h1>⚖️ Mumbai High Court (Bombay HC)</h1>
        <p style="color:#666;margin-top:-8px">Source: <code>bombayhighcourt.nic.in</code> judgment search → <code>generatenewauth.php</code> PDF download → GitHub → Claude summary</p>

        <?php if (!$enabled || $enabled==='0'): ?>
        <div class="notice notice-warning"><p>⚠️ Mumbai HC scraper is <strong>disabled</strong>. Enable it in <a href="<?php echo admin_url('admin.php?page=cl-settings') ?>">Settings</a>.</p></div>
        <?php endif ?>

        <div class="cl-info">
            <strong>How it works:</strong>
            <ol>
                <li>Fetches <code>bombayhighcourt.nic.in/recentorderjudgment.php</code> (plain GET, no CAPTCHA, no session)</li>
                <li>Parses all judgment rows — filters party names for tax keywords (Income Tax, GST, Customs etc.)</li>
                <li>Decodes BASE64 → extracts filename, upload date, and neutral citation (e.g. <code>2026:BHC-AS:9214-DB</code>)</li>
                <li>Downloads judgment PDF directly from BHC NIC server</li>
                <li>Uploads to GitHub under <code>MHC/YYYY/MM/Category/</code></li>
                <li>Claude AI summary → WordPress post via <code>$wpdb</code></li>
            </ol>
        </div>

        <div class="cl-box">
            <h2>⚡ Quick Actions</h2>
            <button id="cl-mhc-run" class="button button-primary button-large">🔄 Run MHC Scrape Now</button>&nbsp;
            <button id="cl-mhc-test" class="button button-large">🧪 Test BHC Connection</button>
            <div id="cl-status"></div>
            <?php if ($next): ?>
            <p style="margin-top:10px;color:#666;font-size:13px">⏰ Next scheduled run: <strong><?php echo date('D d M Y, H:i', $next) ?> UTC</strong> (approx 11:00am IST)</p>
            <?php endif ?>
        </div>

        <?php if ($rows): ?>
        <div class="cl-box">
            <h2>📋 Recent MHC Cases</h2>
            <table class="wp-list-table widefat striped" style="font-size:13px">
                <thead><tr><th>Case Title</th><th>Citation</th><th>Category</th><th>Upload Date</th><th>Status</th><th>Post</th></tr></thead>
                <tbody>
                <?php foreach($rows as $r):
                    $colors=array('completed'=>'green','pending'=>'#888','no_pdf'=>'orange','failed'=>'red','download_failed'=>'red','github_failed'=>'darkorange','post_failed'=>'orange');
                    $c=$colors[$r->status]??'#666';
                ?>
                <tr>
                    <td><?php echo esc_html(substr($r->case_title,0,65)) ?>…</td>
                    <td style="font-size:11px"><?php echo esc_html($r->case_number) ?></td>
                    <td><?php echo esc_html($r->tax_category) ?></td>
                    <td><?php echo esc_html($r->cl_date) ?></td>
                    <td><span style="color:<?php echo $c ?>;font-weight:600"><?php echo esc_html($r->status) ?></span></td>
                    <td><?php if($r->post_id): ?><a href="<?php echo get_edit_post_link($r->post_id) ?>">Edit</a><?php endif ?></td>
                </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
        <?php endif ?>
        </div>

        <script>
        jQuery(function($){
            var n='<?php echo wp_create_nonce("cl_nonce") ?>';

            // ── Run MHC: stepwise fetch → process one at a time ──────────────
            $('#cl-mhc-run').on('click', function(){
                if(!confirm('Search BHC for recent tax judgments and process?')) return;
                var btn=$(this), st=$('#cl-status');
                btn.prop('disabled',true).text('⏳ Step 1: Fetching BHC page…');
                st.html('Connecting to bombayhighcourt.nic.in via ScraperAPI…<br><small>This takes ~10 seconds.</small>');

                // Step 1: fetch + parse
                $.post(ajaxurl, {action:'cl_mhc_fetch', nonce:n}, function(r){
                    if(!r.success){
                        btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                        st.html('❌ ' + r.data);
                        return;
                    }
                    var total = r.data.total;
                    var qkey  = r.data.queue_key;
                    st.html('✅ ' + r.data.message + '<br><div id="cl-progress" style="margin-top:8px;font-family:monospace;font-size:12px;background:#f5f5f5;padding:10px;border-radius:4px;max-height:200px;overflow-y:auto"></div>');
                    btn.text('⏳ Processing 1 of ' + total + '…');

                    // Step 2: process cases one at a time
                    function processNext(done) {
                        if(done >= <?php echo (int)get_option('cl_max_per_run',5) ?>) {
                            btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                            $('#cl-progress').append('<br>✅ Done — max per run reached. Reload page to see results.');
                            return;
                        }
                        $.post(ajaxurl, {action:'cl_mhc_process_one', nonce:n, queue_key:qkey, done:done}, function(r2){
                            if(!r2.success){
                                btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                                st.html('❌ ' + r2.data);
                                return;
                            }
                            var d = r2.data;
                            $('#cl-progress').append(d.message + '<br>');
                            $('#cl-progress').scrollTop($('#cl-progress')[0].scrollHeight);

                            if(d.status === 'done' || d.status === 'limit_reached'){
                                btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                                $('#cl-progress').append('<br>✅ All done! <a href="edit.php?post_type=cl_judgment">View posts →</a>');
                                return;
                            }
                            if(d.continue){
                                btn.text('⏳ Processing ' + (d.done+1) + ' of ' + total + '…');
                                setTimeout(function(){ processNext(d.done); }, 500);
                            } else {
                                btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                                $('#cl-progress').append('<br>✅ Complete! <a href="edit.php?post_type=cl_judgment">View posts →</a>');
                            }
                        }).fail(function(xhr){
                            btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                            st.html('❌ Request failed (HTTP ' + xhr.status + '). Check PHP error log.');
                        });
                    }
                    processNext(0);

                }).fail(function(xhr){
                    btn.prop('disabled',false).text('🔄 Run MHC Scrape Now');
                    st.html('❌ Fetch request failed (HTTP ' + xhr.status + '). Check PHP error log.');
                });
            });

            // ── Test BHC connection ──────────────────────────────────────────
            $('#cl-mhc-test').on('click',function(){
                var btn=$(this), st=$('#cl-status');
                btn.prop('disabled',true).text('Testing…');
                st.html('Probing bombayhighcourt.nic.in via ScraperAPI…');
                $.post(ajaxurl,{action:'cl_mhc_test',nonce:n},function(r){
                    btn.prop('disabled',false).text('🧪 Test BHC Connection');
                    st.html((r.success?'✅ ':'❌ ')+r.data);
                }).fail(function(){ btn.prop('disabled',false).text('🧪 Test BHC Connection'); st.html('❌ Request failed.'); });
            });
        });
        </script>
        <?php
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PAGE: SETTINGS
    // ══════════════════════════════════════════════════════════════════════════
    public function page_settings() {
        if ( isset($_POST['cl_save']) ) {
            check_admin_referer('cl_settings_nonce');
            $fields = array(
                'cl_github_token','cl_github_owner','cl_github_repo',
                'cl_claude_key','cl_auto_publish','cl_max_per_run',
                'cl_sc_enabled','cl_sc_lookback_days',
                'cl_mhc_enabled','cl_mhc_lookback_days',
                'cl_scraperapi_key','cl_proxy_url',
            );
            foreach ( $fields as $f ) update_option( $f, sanitize_text_field($_POST[$f]??'') );
            $sc_cats  = isset($_POST['cl_sc_enabled_categories'])  ? array_map('sanitize_text_field',(array)$_POST['cl_sc_enabled_categories'])  : array();
            $mhc_cats = isset($_POST['cl_mhc_enabled_categories']) ? array_map('sanitize_text_field',(array)$_POST['cl_mhc_enabled_categories']) : array();
            update_option('cl_sc_enabled_categories',  $sc_cats);
            update_option('cl_mhc_enabled_categories', $mhc_cats);
            echo '<div class="notice notice-success"><p>✅ Settings saved!</p></div>';
        }

        $sc_cats  = get_option('cl_sc_enabled_categories',  array());
        $mhc_cats = get_option('cl_mhc_enabled_categories', array());
        $all_cats = array_keys(unserialize(CL_CATEGORY_MAP));
        ?>
        <div class="wrap cl-wrap">
        <?php echo $this->admin_styles(); ?>
        <h1>⚙️ Court Listener — Settings</h1>
        <form method="post"><?php wp_nonce_field('cl_settings_nonce'); ?>
        <table class="form-table">

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">📦 GitHub Storage (shared by all courts)</h2></th></tr>
        <tr>
            <th>Personal Access Token</th>
            <td><input type="password" name="cl_github_token" value="<?php echo esc_attr(get_option('cl_github_token')) ?>" class="regular-text" placeholder="ghp_xxxx"/>
            <p class="description">Needs <strong>repo</strong> scope. <a href="https://github.com/settings/tokens" target="_blank">Create →</a></p></td>
        </tr>
        <tr>
            <th>Repository Owner</th>
            <td><input type="text" name="cl_github_owner" value="<?php echo esc_attr(get_option('cl_github_owner')) ?>" class="regular-text"/></td>
        </tr>
        <tr>
            <th>Repository Name</th>
            <td><input type="text" name="cl_github_repo" value="<?php echo esc_attr(get_option('cl_github_repo')) ?>" class="regular-text" placeholder="court-judgments"/>
            <p class="description">PDFs will be stored as: <code>SC/YYYY/MM/Category/Title.pdf</code> and <code>MHC/YYYY/MM/Category/Title.pdf</code></p></td>
        </tr>
        <tr>
            <td colspan="2"><button type="button" id="cl-gh-test" class="button">🔌 Test GitHub Connection</button>
            <span id="cl-gh-status" style="margin-left:10px;font-weight:600"></span></td>
        </tr>

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">🤖 Claude AI (shared)</h2></th></tr>
        <tr>
            <th>Claude API Key</th>
            <td><input type="password" name="cl_claude_key" value="<?php echo esc_attr(get_option('cl_claude_key')) ?>" class="regular-text" placeholder="sk-ant-xxxx"/>
            <p class="description">Uses <strong>claude-haiku-4-5</strong> for cost efficiency. Falls back to excerpt if blank.</p></td>
        </tr>

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">📝 Publishing (shared)</h2></th></tr>
        <tr>
            <th>Post Status</th>
            <td><select name="cl_auto_publish">
                <option value="draft"   <?php selected(get_option('cl_auto_publish','draft'),'draft') ?>>💾 Draft (Recommended)</option>
                <option value="publish" <?php selected(get_option('cl_auto_publish'),'publish') ?>>🚀 Publish Immediately</option>
            </select></td>
        </tr>
        <tr>
            <th>Max Cases per Run</th>
            <td><input type="number" name="cl_max_per_run" value="<?php echo esc_attr(get_option('cl_max_per_run',5)) ?>" min="1" max="20" class="small-text"/>
            <p class="description">Per court, per run. Each case = PDF download + GitHub upload + Claude call.</p></td>
        </tr>

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">🏛️ Supreme Court Settings</h2></th></tr>
        <tr>
            <th>Enable SC Scraper</th>
            <td><label><input type="checkbox" name="cl_sc_enabled" value="1" <?php checked(get_option('cl_sc_enabled','1'),'1') ?>> Enable daily SC cause list scraping</label></td>
        </tr>
        <tr>
            <th>Lookback Days</th>
            <td><input type="number" name="cl_sc_lookback_days" value="<?php echo esc_attr(get_option('cl_sc_lookback_days',3)) ?>" min="1" max="10" class="small-text"/>
            <p class="description">How many past working days to check if today's list isn't available.</p></td>
        </tr>
        <tr>
            <th>SC Tax Categories</th>
            <td><?php foreach($all_cats as $cat): $chk=in_array($cat,$sc_cats)?'checked':''; ?>
                <label style="display:block;margin-bottom:6px"><input type="checkbox" name="cl_sc_enabled_categories[]" value="<?php echo $cat ?>" <?php echo $chk ?>> <?php echo $cat ?></label>
                <?php endforeach ?>
                <p class="description">Leave all unchecked to collect all categories.</p></td>
        </tr>

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">⚖️ Mumbai High Court Settings</h2></th></tr>
        <tr>
            <th>Enable MHC Scraper</th>
            <td><label><input type="checkbox" name="cl_mhc_enabled" value="1" <?php checked(get_option('cl_mhc_enabled','1'),'1') ?>> Enable daily Mumbai HC judgment fetching</label></td>
        </tr>
        <tr>
            <th>Lookback Days</th>
            <td><input type="number" name="cl_mhc_lookback_days" value="<?php echo esc_attr(get_option('cl_mhc_lookback_days',3)) ?>" min="1" max="10" class="small-text"/>
            <p class="description">Not used for MHC — BHC uploads are date-irregular. All page entries are accepted; duplicates are skipped by case hash.</p></td>
        </tr>
        <tr>
            <th>MHC Tax Categories</th>
            <td><?php foreach($all_cats as $cat): $chk=in_array($cat,$mhc_cats)?'checked':''; ?>
                <label style="display:block;margin-bottom:6px"><input type="checkbox" name="cl_mhc_enabled_categories[]" value="<?php echo $cat ?>" <?php echo $chk ?>> <?php echo $cat ?></label>
                <?php endforeach ?>
                <p class="description">Leave all unchecked to collect all categories.</p></td>
        </tr>

        <tr><th colspan="2"><h2 style="border-bottom:1px solid #eee;padding-bottom:8px">🌐 Proxy Settings <small style="font-weight:400;color:#888">(Required for NIC IP block bypass)</small></h2></th></tr>
        <tr>
            <th>ScraperAPI Key</th>
            <td><input type="password" name="cl_scraperapi_key" value="<?php echo esc_attr(get_option('cl_scraperapi_key')) ?>" class="regular-text" placeholder="your_scraperapi_key"/>
            <p class="description">
                <strong>Why needed:</strong> Both <code>api.sci.gov.in</code> and <code>bombayhighcourt.nic.in</code> block Cloudways datacenter IPs.<br>
                ScraperAPI routes requests through residential IPs — <strong>free tier: 1,000 calls/month</strong> (enough for daily scraping).<br>
                <a href="https://www.scraperapi.com/?fp_ref=court-listener" target="_blank">Get free key →</a> &nbsp;|&nbsp;
                Leave blank to try direct connection (will timeout on most servers).
            </p></td>
        </tr>
        <tr>
            <th>HTTP Proxy URL</th>
            <td><input type="text" name="cl_proxy_url" value="<?php echo esc_attr(get_option('cl_proxy_url')) ?>" class="regular-text" placeholder="http://user:pass@proxy.example.com:8080"/>
            <p class="description">Alternative: your own HTTP proxy. Used only if ScraperAPI key is blank. Format: <code>http://user:pass@host:port</code></p></td>
        </tr>

        </table>
        <p class="submit"><button type="submit" name="cl_save" class="button button-primary button-large">💾 Save Settings</button></p>
        </form>
        </div>

        <script>
        jQuery(function($){
            $('#cl-gh-test').on('click',function(e){
                e.preventDefault();
                var btn=$(this);
                btn.prop('disabled',true).text('Testing…');
                $.post(ajaxurl,{action:'cl_test_github',nonce:'<?php echo wp_create_nonce("cl_nonce") ?>'},function(r){
                    btn.prop('disabled',false).text('🔌 Test GitHub Connection');
                    $('#cl-gh-status').html(r.success
                        ?'<span style="color:green">✅ '+r.data+'</span>'
                        :'<span style="color:red">❌ '+r.data+'</span>');
                }).fail(function(){
                    btn.prop('disabled',false).text('🔌 Test GitHub Connection');
                    $('#cl-gh-status').html('<span style="color:red">❌ Request failed. Check browser console.</span>');
                });
            });
        });
        </script>
        <?php
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PAGE: LOGS
    // ══════════════════════════════════════════════════════════════════════════
    public function page_logs() {
        global $wpdb;
        $court_filter = sanitize_text_field($_GET['court'] ?? '');
        if ($court_filter) {
            $logs = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}cl_logs WHERE court=%s ORDER BY logged_at DESC LIMIT 400",
                $court_filter
            ));
        } else {
            $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cl_logs ORDER BY logged_at DESC LIMIT 400");
        }
        // Debug: also show last wpdb error if logs empty
        $wpdb_last_error = $wpdb->last_error;
        ?>
        <div class="wrap cl-wrap">
        <?php echo $this->admin_styles(); ?>
        <h1>📋 Activity Logs</h1>
        <div style="margin-bottom:14px;display:flex;gap:10px;align-items:center">
            <a href="?page=cl-logs" class="button <?php echo !$court_filter?'button-primary':'' ?>">All Courts</a>
            <a href="?page=cl-logs&court=SC"  class="button <?php echo $court_filter==='SC'?'button-primary':'' ?>">SC Only</a>
            <a href="?page=cl-logs&court=MHC" class="button <?php echo $court_filter==='MHC'?'button-primary':'' ?>">MHC Only</a>
            <button id="cl-clear-logs" class="button" style="margin-left:auto">🗑️ Clear All Logs</button>
        </div>
        <?php if ($logs): ?>
        <table class="wp-list-table widefat striped" style="font-size:12px">
            <thead><tr><th style="width:155px">Time</th><th style="width:50px">Court</th><th style="width:55px">Level</th><th style="width:120px">Context</th><th>Message</th></tr></thead>
            <tbody id="cl-log-tbody">
            <?php foreach($logs as $l):
                $c=array('success'=>'green','error'=>'red','warn'=>'darkorange','info'=>'#0073aa')[$l->level]??'#666';
            ?>
            <tr>
                <td><?php echo esc_html($l->logged_at) ?></td>
                <td><span class="cl-badge <?php echo strtolower($l->court) ?>"><?php echo esc_html($l->court) ?></span></td>
                <td><span style="color:<?php echo $c ?>;font-weight:600"><?php echo strtoupper(esc_html($l->level)) ?></span></td>
                <td><?php echo esc_html($l->context) ?></td>
                <td><?php echo esc_html($l->message) ?></td>
            </tr>
            <?php endforeach ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No logs yet.</p>
        <?php if ($wpdb_last_error): ?>
        <div class="notice notice-error"><p>DB Error: <?php echo esc_html($wpdb_last_error) ?></p></div>
        <?php endif ?>
        <?php endif ?>
        </div>
        <script>
        jQuery(function($){
            $('#cl-clear-logs').on('click',function(){
                if(!confirm('Clear all logs?'))return;
                $.post(ajaxurl,{action:'cl_clear_logs',nonce:'<?php echo wp_create_nonce("cl_nonce") ?>'},function(r){
                    if(r.success)location.reload();
                });
            });
        });
        </script>
        <?php
    }

    // ══════════════════════════════════════════════════════════════════════════
    // AJAX HANDLERS
    // ══════════════════════════════════════════════════════════════════════════
    private function verify_ajax() {
        check_ajax_referer('cl_nonce','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
    }

    // ── Stepwise AJAX handlers (avoids long-running request timeouts) ─────────
    // Instead of one long synchronous request, JS drives a loop:
    //   1. ajax_mhc_fetch   → fetch BHC page, parse cases, cache in transient (~10s)
    //   2. ajax_mhc_process_one → process ONE case per call (~20s each)
    // JS calls process_one repeatedly until queue is empty.
    // Each call stays under 60s. No background execution, no cron, no loopback.

    public function ajax_sc_run() {
        $this->verify_ajax();
        // Legacy handler — redirect to stepwise
        wp_send_json_success( 'use_stepwise' );
    }

    public function ajax_mhc_run() {
        $this->verify_ajax();
        // Legacy handler — redirect to stepwise
        wp_send_json_success( 'use_stepwise' );
    }

    // ── SC: Step 1 — fetch cause list, return case list to JS ────────────────
    public function ajax_sc_fetch() {
        $this->verify_ajax();
        @set_time_limit(120);

        $lookback = (int)get_option('cl_sc_lookback_days', 3);
        $enabled_cats = get_option('cl_sc_enabled_categories', array());
        $all_cases = array();

        $ts = time(); $working = 0; $tried = 0;
        while ($working <= $lookback && $tried < 14) {
            $dow = (int)date('N',$ts); $date = date('Y-m-d',$ts); $tried++;
            $ts -= DAY_IN_SECONDS;
            if ($dow > 5) continue;
            $working++;
            $cl_text = $this->sc_fetch_cause_list($date);
            if ($cl_text) {
                $cases = $this->sc_parse_tax_cases($cl_text, $date);
                $all_cases = array_merge($all_cases, $cases);
            }
        }

        if (empty($all_cases)) {
            wp_send_json_error('No tax cases found in SC cause list. Court may be on vacation or api.sci.gov.in is down.');
        }

        // Filter and dedup
        $queue = array();
        foreach ($all_cases as $case) {
            if (!empty($enabled_cats) && !in_array($case['category'], $enabled_cats)) continue;
            $hash = hash('sha256', $case['title'].'|'.$case['case_number'].'|'.$case['diary_number']);
            if ($this->is_processed('sc', $hash)) continue;
            $case['hash'] = $hash;
            $queue[] = $case;
        }

        if (empty($queue)) {
            wp_send_json_error('No new SC tax cases — all already processed.');
        }

        // Cache queue in transient (10 min TTL)
        $key = 'cl_sc_queue_' . get_current_user_id();
        set_transient($key, $queue, 10 * MINUTE_IN_SECONDS);

        wp_send_json_success(array(
            'total'   => count($queue),
            'message' => count($queue) . ' new SC tax cases found. Processing one at a time…',
            'queue_key' => $key,
        ));
    }

    // ── SC: Step 2 — process ONE case from queue ─────────────────────────────
    public function ajax_sc_process_one() {
        $this->verify_ajax();
        @set_time_limit(120);

        $key   = sanitize_text_field($_POST['queue_key'] ?? '');
        $max   = (int)get_option('cl_max_per_run', 5);
        $done  = (int)($_POST['done'] ?? 0);

        if (empty($key)) wp_send_json_error('Missing queue key.');
        if ($done >= $max) {
            wp_send_json_success(array('status'=>'limit_reached','message'=>"Max per run ({$max}) reached."));
        }

        $queue = get_transient($key);
        if (empty($queue)) {
            wp_send_json_success(array('status'=>'done','message'=>'Queue empty — all cases processed.'));
        }

        // Take first case off queue
        $case = array_shift($queue);
        set_transient($key, $queue, 10 * MINUTE_IN_SECONDS);

        $result = $this->sc_process_case($case, $case['hash']);

        $status = $result === true ? 'saved' : ($result === 'no_pdf' ? 'no_pdf' : 'error');
        $remaining = count($queue);

        wp_send_json_success(array(
            'status'    => $status,
            'case'      => substr($case['title'], 0, 80),
            'remaining' => $remaining,
            'message'   => "[$status] " . substr($case['title'], 0, 60) . " | {$remaining} remaining",
            'done'      => $done + 1,
            'continue'  => $remaining > 0 && ($done + 1) < $max,
        ));
    }

    // ── MHC: Step 1 — fetch BHC page, return case list to JS ─────────────────
    public function ajax_mhc_fetch() {
        $this->verify_ajax();
        @set_time_limit(120);

        $enabled_cats = get_option('cl_mhc_enabled_categories', array());

        $result = $this->mhc_search_judgments(null, null, false);
        if (!$result['success'] || empty($result['cases'])) {
            wp_send_json_error($result['message'] ?? 'No MHC tax cases found.');
        }

        // Filter already-processed
        $queue = array();
        foreach ($result['cases'] as $case) {
            if (!empty($enabled_cats) && !in_array($case['category'], $enabled_cats)) continue;
            $hash = hash('sha256', $case['title'].'|'.$case['case_number'].'|'.$case['cl_date']);
            if ($this->is_processed('mhc', $hash)) continue;
            $case['hash'] = $hash;
            $queue[] = $case;
        }

        if (empty($queue)) {
            wp_send_json_error('No new MHC tax cases — all ' . count($result['cases']) . ' found are already processed.');
        }

        $key = 'cl_mhc_queue_' . get_current_user_id();
        set_transient($key, $queue, 10 * MINUTE_IN_SECONDS);

        wp_send_json_success(array(
            'total'     => count($queue),
            'message'   => count($queue) . ' new MHC tax cases found. Processing one at a time…',
            'queue_key' => $key,
        ));
    }

    // ── MHC: Step 2 — process ONE case from queue ────────────────────────────
    public function ajax_mhc_process_one() {
        $this->verify_ajax();
        @set_time_limit(120);

        $key  = sanitize_text_field($_POST['queue_key'] ?? '');
        $max  = (int)get_option('cl_max_per_run', 5);
        $done = (int)($_POST['done'] ?? 0);

        if (empty($key)) wp_send_json_error('Missing queue key.');
        if ($done >= $max) {
            wp_send_json_success(array('status'=>'limit_reached','message'=>"Max per run ({$max}) reached."));
        }

        $queue = get_transient($key);
        if (empty($queue)) {
            wp_send_json_success(array('status'=>'done','message'=>'Queue empty — all cases processed.'));
        }

        $case = array_shift($queue);
        set_transient($key, $queue, 10 * MINUTE_IN_SECONDS);

        $result = $this->mhc_process_case($case, $case['hash']);

        $status    = $result === true ? 'saved' : ($result === 'no_pdf' ? 'no_pdf' : 'error');
        $remaining = count($queue);

        wp_send_json_success(array(
            'status'    => $status,
            'case'      => substr($case['title'], 0, 80),
            'remaining' => $remaining,
            'message'   => "[$status] " . substr($case['title'], 0, 60) . " | {$remaining} remaining",
            'done'      => $done + 1,
            'continue'  => $remaining > 0 && ($done + 1) < $max,
        ));
    }

    public function ajax_sc_test() {
        $this->verify_ajax();
        $today = date('Y-m-d');
        $probe_url = "https://api.sci.gov.in/jonew/cl/{$today}/M_J.pdf";

        $probe = $this->proxy_get($probe_url, array(
            'timeout' => 15,
            'headers' => array(
                'User-Agent'      => 'Mozilla/5.0 (X11; Linux x86_64; compatible; Googlebot/2.1)',
                'Accept'          => 'application/pdf,*/*',
                'Accept-Language' => 'en-IN,en;q=0.9',
                'Referer'         => 'https://main.sci.gov.in/',
            ),
        ));

        if (is_wp_error($probe)) {
            $err = $probe->get_error_message();
            if (strpos($err,'cURL error 28')!==false||strpos($err,'timed out')!==false) {
                wp_send_json_error("⏱️ TIMEOUT — api.sci.gov.in is not responding (cURL error 28). Your server IP may be rate-limited. Try again in 30 minutes.");
            }
            wp_send_json_error("🔌 CONNECTION ERROR — {$err}");
        }

        $code = wp_remote_retrieve_response_code($probe);
        $body = wp_remote_retrieve_body($probe);

        if (strpos($body,'SQLSTATE')!==false || strpos($body,'is not allowed to connect')!==false) {
            preg_match('/SQLSTATE[^\n<]{0,200}/',$body,$sql_err);
            $sql_msg = !empty($sql_err[0]) ? trim($sql_err[0]) : 'MySQL connection refused';
            wp_send_json_error("🔴 SCI SERVER DATABASE ERROR — HTTP {$code} but MySQL error returned:\n\n  {$sql_msg}\n\nThis is SCI's internal issue, not yours. Try again in a few hours.");
        }

        // Try to get actual cause list
        $dates = array(); $ts = time();
        for ($i=0;$i<10&&count($dates)<5;$i++) {
            $dow=(int)date('N',$ts);
            if ($dow<=5) $dates[]=date('Y-m-d',$ts);
            $ts-=DAY_IN_SECONDS;
        }

        $cl_text=false; $cl_date='';
        foreach ($dates as $d) {
            $cl_text=$this->sc_fetch_cause_list($d);
            if ($cl_text){$cl_date=$d;break;}
        }

        if (!$cl_text) {
            $dow=(int)date('N');
            $is_weekend=$dow>=6;
            $msg="Could not retrieve a usable cause list.\nDates tried: ".implode(', ',$dates);
            if ($is_weekend) $msg.="\n\nToday is ".date('l')." — court does not sit on weekends. This is expected.";
            wp_send_json_error($msg);
        }

        $cases = $this->sc_parse_tax_cases($cl_text, $cl_date);
        $preview='';
        foreach(array_slice($cases,0,5) as $i=>$c) {
            $preview.=($i+1).". {$c['title']} | {$c['case_number']} | Diary:{$c['diary_number']} | {$c['category']}\n";
        }

        $msg="Cause list for {$cl_date} — ".number_format(strlen($cl_text))." chars\nTax cases found: ".count($cases)."\n";
        if ($preview) $msg.="\nFirst 5:\n".$preview;
        wp_send_json_success($msg);
    }

    public function ajax_mhc_test() {
        $this->verify_ajax();
        $result = $this->mhc_search_judgments( null, null, true );
        if ($result['success']) {
            wp_send_json_success($result['message']);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_test_github() {
        $this->verify_ajax();
        $token=get_option('cl_github_token');
        $owner=get_option('cl_github_owner');
        $repo =get_option('cl_github_repo');
        if (empty($token)||empty($owner)||empty($repo)) wp_send_json_error('Fill in all GitHub fields first.');
        $res=wp_remote_get("https://api.github.com/repos/{$owner}/{$repo}",array(
            'headers'=>array('Authorization'=>'token '.$token,'User-Agent'=>'Court-Listener'),
        ));
        $code=wp_remote_retrieve_response_code($res);
        if ($code===200) { wp_send_json_success("Connected! {$owner}/{$repo} is accessible."); }
        elseif ($code===404) {
            $create=wp_remote_post('https://api.github.com/user/repos',array(
                'headers'=>array('Authorization'=>'token '.$token,'Content-Type'=>'application/json','User-Agent'=>'Court-Listener'),
                'body'=>json_encode(array('name'=>$repo,'auto_init'=>true,'description'=>'Indian Court Judgment PDFs — Court Listener')),
            ));
            wp_remote_retrieve_response_code($create)===201
                ?wp_send_json_success("Repo {$owner}/{$repo} created!")
                :wp_send_json_error("Repo not found and could not create. Check token scope.");
        } else { wp_send_json_error("Failed. HTTP {$code}."); }
    }

    public function ajax_clear_logs() {
        $this->verify_ajax();
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}cl_logs");
        wp_send_json_success('Logs cleared.');
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SUPREME COURT PIPELINE
    // ══════════════════════════════════════════════════════════════════════════

    public function run_sc_scrape() {
        @set_time_limit(0); // Bypass PHP timeout for background cron runs
        if (!get_option('cl_sc_enabled','1')) {
            return array('success'=>false,'message'=>'SC scraper is disabled.');
        }
        $this->log('SC','info','scrape','SC daily scrape started');

        $max         = (int)get_option('cl_max_per_run',5);
        $lookback    = (int)get_option('cl_sc_lookback_days',3);
        $enabled_cats= get_option('cl_sc_enabled_categories',array());

        $all_cases = array();
        $ts = time(); $working=0; $tried=0;
        while ($working<=$lookback && $tried<14) {
            $dow=(int)date('N',$ts); $date=date('Y-m-d',$ts); $tried++;
            $ts-=DAY_IN_SECONDS;
            if ($dow>5) continue;
            $working++;
            $cl_text=$this->sc_fetch_cause_list($date);
            if ($cl_text) {
                $cases=$this->sc_parse_tax_cases($cl_text,$date);
                $this->log('SC','info','cause_list',"Date {$date}: ".count($cases)." tax cases found");
                $all_cases=array_merge($all_cases,$cases);
            } else {
                $this->log('SC','info','cause_list',"Date {$date}: no cause list (holiday or DB error)");
            }
        }

        if (empty($all_cases)) {
            $msg='No tax cases found in SC cause list.';
            $this->log('SC','warn','scrape',$msg);
            return array('success'=>false,'message'=>$msg);
        }

        $saved=$skipped=$no_pdf=$errors=0;
        foreach ($all_cases as $case) {
            if ($saved>=$max) break;
            if (!empty($enabled_cats)&&!in_array($case['category'],$enabled_cats)){$skipped++;continue;}
            $hash=hash('sha256',$case['title'].'|'.$case['case_number'].'|'.$case['diary_number']);
            if ($this->is_processed('sc',$hash)){$skipped++;continue;}
            $result=$this->sc_process_case($case,$hash);
            if     ($result===true)     $saved++;
            elseif ($result==='no_pdf') $no_pdf++;
            else                        $errors++;
            sleep(2);
        }

        $msg="SC done — saved:{$saved} skipped:{$skipped} no_pdf:{$no_pdf} errors:{$errors}";
        $this->log('SC','success','scrape',$msg);
        return array('success'=>true,'message'=>$msg);
    }

    // ── SC Step 1: Fetch cause list ───────────────────────────────────────────
    private function sc_fetch_cause_list($date) {
        $block_key = 'cl_sci_blocked_'.date('YmdH');
        if (get_transient($block_key)) {
            $this->log('SC','warn','cause_list',"Skipping {$date} — api.sci.gov.in blocked this hour (cached)");
            return false;
        }

        $primary = "https://api.sci.gov.in/jonew/cl/{$date}/M_J.pdf";
        $headers  = array(
            'User-Agent'      => 'Mozilla/5.0 (X11; Linux x86_64; compatible; Googlebot/2.1)',
            'Accept'          => 'application/pdf,*/*',
            'Accept-Language' => 'en-IN,en;q=0.9',
            'Referer'         => 'https://main.sci.gov.in/',
        );

        $probe = $this->proxy_get($primary, array('timeout'=>12,'headers'=>$headers));

        if (is_wp_error($probe)) {
            $err=$probe->get_error_message();
            if (strpos($err,'cURL error 28')!==false||strpos($err,'timed out')!==false) {
                set_transient($block_key,1,30*MINUTE_IN_SECONDS);
                $this->log('SC','warn','cause_list',"Timeout for {$date} — blocked 30 min");
                return false;
            }
            $this->log('SC','warn','cause_list',"Probe error {$date}: {$err}");
            return false;
        }

        $probe_code=wp_remote_retrieve_response_code($probe);
        $probe_body=wp_remote_retrieve_body($probe);

        // Detect SCI MySQL error
        if (strpos($probe_body,'SQLSTATE')!==false||strpos($probe_body,'is not allowed to connect')!==false) {
            $this->log('SC','error','cause_list',"SCI DB error for {$date} — their MySQL is down. Retry later.");
            return false;
        }

        if ($probe_code===200&&strpos($probe_body,'%PDF')===0&&strlen($probe_body)>10000) {
            $text=$this->extract_pdf_text($probe_body);
            if (!empty($text)&&strlen($text)>500) {
                $this->log('SC','info','cause_list',"Fetched {$primary} — ".number_format(strlen($text))." chars");
                return $text;
            }
        }

        // Try remaining variants (server is reachable — just 404)
        $variants = array(
            "https://api.sci.gov.in/jonew/cl/{$date}/M_J_1.pdf",
            "https://api.sci.gov.in/jonew/cl/{$date}/M_R.pdf",
            "https://api.sci.gov.in/jonew/cl/{$date}/M_R_1.pdf",
            "https://api.sci.gov.in/jonew/cl/{$date}/S_J.pdf",
            "https://api.sci.gov.in/jonew/cl/{$date}/M_J_2.pdf",
            "https://api.sci.gov.in/jonew/cl/advance/{$date}/M_J.pdf",
            "https://api.sci.gov.in/jonew/cl/advance/{$date}/M_J_1.pdf",
        );

        foreach ($variants as $url) {
            $resp=$this->proxy_get($url,array('timeout'=>25,'headers'=>$headers));
            if (is_wp_error($resp)) {
                $err=$resp->get_error_message();
                if (strpos($err,'cURL error 28')!==false||strpos($err,'timed out')!==false) {
                    set_transient($block_key,1,30*MINUTE_IN_SECONDS);
                    $this->log('SC','warn','cause_list',"Timeout mid-loop for {$date} — aborting");
                    return false;
                }
                continue;
            }
            if (wp_remote_retrieve_response_code($resp)!==200) continue;
            $body=wp_remote_retrieve_body($resp);
            if (strpos($body,'%PDF')!==0||strlen($body)<10000) continue;
            $text=$this->extract_pdf_text($body);
            if (!empty($text)&&strlen($text)>500) {
                $this->log('SC','info','cause_list',"Fetched {$url} — ".number_format(strlen($text))." chars");
                return $text;
            }
        }

        return false;
    }

    // ── SC Step 2: Parse tax cases from cause list text ───────────────────────
    private function sc_parse_tax_cases($text, $date) {
        $cases=array();
        $tax_keywords=unserialize(CL_TAX_KEYWORDS);
        $cat_map=unserialize(CL_CATEGORY_MAP);

        $text=preg_replace('/[ \t]+',' ',$text);
        $lines=explode("\n",$text);
        $n=count($lines);
        $i=0;

        while ($i<$n) {
            $line=trim($lines[$i]);
            if (empty($line)){$i++;continue;}
            $line_upper=strtoupper($line);
            $is_tax=false;
            foreach ($tax_keywords as $kw) {
                if (strlen($kw) <= 5) {
                    if (preg_match('/\b' . preg_quote($kw, '/') . '\b/', $line_upper)) { $is_tax=true; break; }
                } else {
                    if (strpos($line_upper,$kw)!==false){$is_tax=true;break;}
                }
            }
            if (!$is_tax){$i++;continue;}

            $start=max(0,$i-3);
            $end=min($n-1,$i+7);
            $block='';
            for ($j=$start;$j<=$end;$j++) $block.=$lines[$j]."\n";

            $case_number='';
            if (preg_match('/\b(SLP\(C\)|SLP\(Crl\)|C\.A\.|W\.P\.\(C\)|Crl\.A\.|T\.P\.\(C\))\s*No\.?\s*[\d\-\/]+/i',$block,$m))
                $case_number=trim($m[0]);

            $diary_number='';
            if (preg_match('/Diary\s+No\.?\s*([\d]+)[\-\/\s]+([\d]{4})/i',$block,$m))
                $diary_number=$m[1].'-'.$m[2];
            elseif (preg_match('/Diary\s+Number\s+([\d]+)\s*\/\s*([\d]{4})/i',$block,$m))
                $diary_number=$m[1].'-'.$m[2];

            $title=$this->sc_extract_title($block);
            if (empty($title)) {
                $title=trim(strip_tags($line));
                for ($j=$i+1;$j<=min($n-1,$i+3);$j++) {
                    $nl=trim($lines[$j]);
                    if (!empty($nl)&&strtolower($nl)!=='versus'&&strlen($title.$nl)<200){
                        $title.=' vs '.$nl;break;
                    }
                }
            }
            if (empty($title)||strlen($title)<10){$i++;continue;}

            $category=$this->detect_category($block,$cat_map);

            $already=false;
            foreach ($cases as $ex) {
                if ($ex['case_number']&&$ex['case_number']===$case_number){$already=true;break;}
            }
            if (!$already) {
                $cases[]=array(
                    'title'        => substr($title,0,500),
                    'case_number'  => $case_number,
                    'diary_number' => $diary_number,
                    'category'     => $category,
                    'cl_date'      => $date,
                );
            }
            $i=$end+1;
        }
        return $cases;
    }

    private function sc_extract_title($block) {
        $upper=strtoupper($block);
        $vs_pos=strpos($upper,'VERSUS');
        if ($vs_pos===false) $vs_pos=strpos($upper,' VS ');
        if ($vs_pos===false) return '';

        $before=trim(substr($block,0,$vs_pos));
        $after=trim(substr($block,$vs_pos+6));
        $after_lines=explode("\n",$after);
        $respondent='';
        foreach ($after_lines as $al) {
            $al=trim($al);
            if (empty($al)) break;
            if (preg_match('/\b(SLP|C\.A\.|W\.P\.|IA No|Diary)/i',$al)) break;
            $respondent.=' '.$al;
            if (strlen($respondent)>100) break;
        }
        $before_lines=array_filter(array_map('trim',explode("\n",$before)));
        $petitioner=implode(' ',array_slice(array_values($before_lines),-2));
        $petitioner=trim(preg_replace('/\s+/',' ',$petitioner));
        if (empty($petitioner)) return '';
        return substr($petitioner,0,200).' vs '.trim(substr($respondent,0,200));
    }

    // ── SC Step 3: Find judgment PDF ──────────────────────────────────────────
    private function sc_find_judgment_pdf($case) {
        if (empty($case['diary_number'])) return null;
        if (!preg_match('/^(\d+)-(\d{4})$/',$case['diary_number'],$m)) return null;
        $diary=$m[1]; $year=$m[2];

        $base_headers=array(
            'User-Agent'=>'Mozilla/5.0 (X11; Linux x86_64; compatible; Googlebot/2.1)',
            'Referer'   =>'https://main.sci.gov.in/',
            'Accept'    =>'application/json, text/html, */*',
        );

        // Strategy A: openCaseJudgment JSON API
        $api_url="https://api.sci.gov.in/jonew/judis/openCaseJudgment/{$diary}/{$year}";
        $resp=wp_remote_get($api_url,array('timeout'=>15,'headers'=>$base_headers));
        if (!is_wp_error($resp)&&wp_remote_retrieve_response_code($resp)===200) {
            $body=wp_remote_retrieve_body($resp);
            $json=json_decode($body,true);
            if (!empty($json)) {
                $path=$json['judgmentFilePath']??$json['judgment_file_path']??$json['filePath']??null;
                if (!$path) {
                    array_walk_recursive($json,function($val) use (&$path){
                        if (is_string($val)&&stripos($val,'Judgement')!==false&&stripos($val,'.pdf')!==false) $path=$val;
                    });
                }
                if ($path) {
                    if (strpos($path,'http')!==0) $path='https://api.sci.gov.in'.(strpos($path,'/')===0?'':'/').$path;
                    $this->log('SC','info','pdf_find',"Strategy A: {$path}");
                    return $path;
                }
            }
        }

        // Strategy B: JUDIS HTML page
        $judis_url="https://api.sci.gov.in/jonew/judis/{$diary}/{$year}";
        $judis=wp_remote_get($judis_url,array('timeout'=>15,'headers'=>$base_headers));
        if (!is_wp_error($judis)&&wp_remote_retrieve_response_code($judis)===200) {
            $html=wp_remote_retrieve_body($judis);
            if (preg_match_all('/href=["\']([^"\']*(?:Judgement|judgment)[^"\']*\.pdf)["\']/',$html,$links,PREG_SET_ORDER)) {
                foreach ($links as $link) {
                    $href=$link[1];
                    if (strpos($href,'http')!==0) $href='https://api.sci.gov.in'.(strpos($href,'/')===0?'':'/').$href;
                    $this->log('SC','info','pdf_find',"Strategy B: {$href}");
                    return $href;
                }
            }
            if (preg_match('/href=["\']([^"\']*'.preg_quote($diary,'/').'[^"\']*\.pdf)["\']/',$html,$link)) {
                $href=$link[1];
                if (strpos($href,'http')!==0) $href='https://api.sci.gov.in'.(strpos($href,'/')===0?'':'/').$href;
                $this->log('SC','info','pdf_find',"Strategy B (diary match): {$href}");
                return $href;
            }
        }

        // Strategy C: getJudgmentList XML index
        $xml_url="https://api.sci.gov.in/jonew/judis/getJudgmentList/{$diary}/{$year}";
        $xml=wp_remote_get($xml_url,array('timeout'=>12,'headers'=>$base_headers));
        if (!is_wp_error($xml)&&wp_remote_retrieve_response_code($xml)===200) {
            $xml_body=wp_remote_retrieve_body($xml);
            if (preg_match('/(\/supremecourt\/[^\s"\'<>]+\.pdf)/',$xml_body,$pm)) {
                $full='https://api.sci.gov.in'.$pm[1];
                $this->log('SC','info','pdf_find',"Strategy C: {$full}");
                return $full;
            }
        }

        $this->log('SC','warn','pdf_find',"No judgment PDF for diary {$diary}-{$year} ({$case['title']})");
        return null;
    }

    // ── SC: Process one case (steps 3-7) ─────────────────────────────────────
    private function sc_process_case($case, $hash) {
        global $wpdb;
        $ct=$wpdb->prefix.'cl_sc_cases';

        $wpdb->insert($ct,array(
            'case_hash'   =>$hash,
            'case_title'  =>substr($case['title'],0,599),
            'case_number' =>$case['case_number'],
            'diary_number'=>$case['diary_number'],
            'cl_date'     =>$case['cl_date'],
            'tax_category'=>$case['category'],
            'status'      =>'pending',
        ));

        $pdf_url=$this->sc_find_judgment_pdf($case);
        if (!$pdf_url) {
            $wpdb->update($ct,array('status'=>'no_pdf'),array('case_hash'=>$hash));
            return 'no_pdf';
        }

        $pdf_content=$this->download_pdf($pdf_url,'SC');
        if (!$pdf_content) {
            $wpdb->update($ct,array('pdf_url'=>$pdf_url,'status'=>'download_failed'),array('case_hash'=>$hash));
            return false;
        }

        $pdf_text=$this->extract_pdf_text($pdf_content);
        if (empty($pdf_text)||strlen($pdf_text)<200) {
            $this->log('SC','warn','process',"PDF text extraction failed for {$case['title']}");
            $pdf_text='';
        }

        $github_url=$this->upload_to_github($pdf_content,$case['title'],$case['category'],$case['cl_date'],'SC');
        if (!$github_url) {
            $wpdb->update($ct,array('pdf_url'=>$pdf_url,'status'=>'github_failed'),array('case_hash'=>$hash));
            return false;
        }

        $summary=$this->generate_summary($case['title'],$case,$pdf_text,'Supreme Court of India');

        $post_id=$this->create_wp_post($case,$github_url,$summary,'SC','Supreme Court of India');
        if (!$post_id) {
            $wpdb->update($ct,array('pdf_url'=>$pdf_url,'github_url'=>$github_url,'status'=>'post_failed'),array('case_hash'=>$hash));
            return false;
        }

        $wpdb->update($ct,array(
            'pdf_url'   =>$pdf_url,
            'github_url'=>$github_url,
            'post_id'   =>$post_id,
            'status'    =>'completed',
        ),array('case_hash'=>$hash));

        $this->log('SC','success','process',"Post #{$post_id}: {$case['title']}");
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  MUMBAI HIGH COURT PIPELINE
    // ══════════════════════════════════════════════════════════════════════════

    public function run_mhc_scrape() {
        @set_time_limit(0); // Bypass PHP timeout for background cron runs
        if (!get_option('cl_mhc_enabled','1')) {
            return array('success'=>false,'message'=>'MHC scraper is disabled.');
        }
        $this->log('MHC','info','scrape','MHC daily scrape started');

        $max          = (int)get_option('cl_max_per_run',5);
        $lookback     = (int)get_option('cl_mhc_lookback_days',3);
        $enabled_cats = get_option('cl_mhc_enabled_categories',array());

        // Build date range: today back lookback working days
        $dates=array(); $ts=time(); $working=0; $tried=0;
        while ($working<=$lookback&&$tried<14) {
            $dow=(int)date('N',$ts); $tried++;
            $ts-=DAY_IN_SECONDS;
            if ($dow>5) continue;
            $working++;
            $dates[]=date('Y-m-d',strtotime("+{$tried} days",$ts));
        }

        // Search BHC for each working day
        // BHC: don't filter by date — rely on hash dedup instead.
        // BHC uploads judgments irregularly (holidays, weekends delay uploads),
        // so a fixed lookback window silently misses valid entries.
        // We pass null dates = accept all entries on the page, dedup by case_hash.
        $search_result=$this->mhc_search_judgments(null, null, false);
        if (!$search_result['success']||empty($search_result['cases'])) {
            $msg=$search_result['message']??'No MHC tax judgments found.';
            $this->log('MHC','warn','scrape',$msg);
            return array('success'=>false,'message'=>$msg);
        }

        $all_cases=$search_result['cases'];
        $this->log('MHC','info','scrape',count($all_cases)." MHC cases found in search");

        $saved=$skipped=$no_pdf=$errors=0;
        foreach ($all_cases as $case) {
            if ($saved>=$max) break;
            if (!empty($enabled_cats)&&!in_array($case['category'],$enabled_cats)){$skipped++;continue;}
            $hash=hash('sha256',$case['title'].'|'.$case['case_number'].'|'.$case['cl_date']);
            if ($this->is_processed('mhc',$hash)){$skipped++;continue;}
            $result=$this->mhc_process_case($case,$hash);
            if     ($result===true)     $saved++;
            elseif ($result==='no_pdf') $no_pdf++;
            else                        $errors++;
            sleep(3);
        }

        $msg="MHC done — saved:{$saved} skipped:{$skipped} no_pdf:{$no_pdf} errors:{$errors}";
        $this->log('MHC','success','scrape',$msg);
        return array('success'=>true,'message'=>$msg);
    }

    // ── MHC Step 1: Search BHC NIC for recent tax judgments ───────────────────
    // ── MHC Step 1: Fetch & filter recent judgments from BHC NIC ────────────
    /**
     * CONFIRMED WORKING ENDPOINT (verified April 15, 2026):
     *   GET https://bombayhighcourt.nic.in/recentorderjudgment.php
     *
     * Plain HTML page — no POST, no CAPTCHA, no session.
     * Returns a table of all recent BHC judgments across all benches:
     *   Matter No. | Party (Petitioner Vs Respondent) | Coram | Order Date
     *   Download link: generatenewauth.php?bhcpar=BASE64
     *
     * We fetch this page, parse all rows, filter by tax keywords in party names,
     * apply date range filter, then process matching cases.
     *
     * NOTE: ord_qrywebcase.php (old POST search) times out from datacenter IPs —
     * do NOT use it. recentorderjudgment.php works from all IPs.
     *
     * SPASSPHRASE in bhcpar is server timestamp at page-serve time (DDMMYYHHMMSS).
     * Links must be used same-day. Since we fetch + process in one run, always fresh.
     */
    private function mhc_search_judgments($from_date, $to_date, $test_mode=false) {
        $cat_map = unserialize(CL_CATEGORY_MAP);
        $tax_kws = unserialize(CL_TAX_KEYWORDS);

        $source_url = 'https://bombayhighcourt.nic.in/recentorderjudgment.php';
        $headers = array(
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept'     => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Referer'    => 'https://bombayhighcourt.nic.in/',
        );

        $resp = $this->proxy_get($source_url, array('timeout'=>20,'headers'=>$headers));

        if (is_wp_error($resp)) {
            $err = $resp->get_error_message();
            $msg = (strpos($err,'cURL error 28')!==false||strpos($err,'timed out')!==false)
                ? "⏱️ TIMEOUT — bombayhighcourt.nic.in not responding. Try again later."
                : "🔌 CONNECTION ERROR — {$err}";
            return array('success'=>false,'message'=>$msg,'cases'=>array());
        }

        $code = wp_remote_retrieve_response_code($resp);
        if ($code !== 200) {
            return array('success'=>false,'message'=>"BHC returned HTTP {$code} on recentorderjudgment.php.",'cases'=>array());
        }

        $html = wp_remote_retrieve_body($resp);
        if (empty($html)) {
            return array('success'=>false,'message'=>"BHC returned empty response.",'cases'=>array());
        }

        if ($test_mode) {
            $total = substr_count($html, 'bhcpar=');
            return array(
                'success' => true,
                'message' => "bombayhighcourt.nic.in/recentorderjudgment.php reachable (HTTP {$code}).\n"
                           . "Total judgment entries on page: {$total}\n"
                           . "Will filter for tax keywords — all dates accepted (dedup by case hash).",
                'cases'   => array(),
            );
        }

        $this->log('MHC','info','search',"Fetched recentorderjudgment.php — ".strlen($html)." chars");

        $all_cases = $this->mhc_parse_recent_judgments($html, $cat_map, $tax_kws);
        $this->log('MHC','info','search',count($all_cases)." tax cases after keyword filter");

        if (empty($all_cases)) {
            return array(
                'success' => false,
                'message' => "No tax judgments found on BHC recent list after keyword filter.\nPage loaded OK ({$code}) but no entries matched Income Tax / GST / Customs / FEMA keywords.\nCheck your enabled categories in Settings.",
                'cases'   => array(),
            );
        }

        return array('success'=>true,'message'=>count($all_cases)." MHC tax cases found",'cases'=>$all_cases);
    }

    // ── MHC: Parse recentorderjudgment.php HTML ───────────────────────────────
    /**
     * Table rows format (confirmed from live page April 2026):
     *   Col 0: Sr.No
     *   Col 1: Matter No. + Bench  (e.g. "WP/13340/2025 BOMBAY")
     *   Col 2: Party Vs Party
     *   Col 3: Coram (judge names)
     *   Col 4: Order Date [J/O]
     * Download href: generatenewauth.php?bhcpar=BASE64  or  generatepdf.php?bhcpar=BASE64
     */
    private function mhc_parse_recent_judgments($html, $cat_map, $tax_kws) {
        $cases = array();
        if (empty($html)) return $cases;

        // Extract all table rows
        preg_match_all('/<tr[^>]*>(.*?)<\/tr>/si', $html, $rows);

        foreach ($rows[1] as $row) {
            // Get cell contents (raw HTML for link extraction, stripped text for data)
            preg_match_all('/<td[^>]*>(.*?)<\/td>/si', $row, $cells_html);
            $cols_html = $cells_html[1] ?? array();
            $cols = array_map(function($c){ return trim(strip_tags($c)); }, $cols_html);

            if (count($cols) < 4) continue;
            // Skip header rows
            if (preg_match('/^(sr\.?\s*no|\d+)$/i', $cols[0]) === 0 && !is_numeric($cols[0])) continue;

            // Party names for keyword matching (col 2)
            $party_text = strtoupper($cols[2] ?? '');

            // Order date (last col), strip [J]/[O]
            $last_col = trim(end($cols));
            $order_date_raw = preg_replace('/\s*\[.\]\s*$/', '', $last_col);

            // Parse DD/MM/YYYY → YYYY-MM-DD
            $case_date = '';
            if (preg_match('/(\d{2})\/(\d{2})\/(\d{4})/', $order_date_raw, $dm)) {
                $case_date = "{$dm[3]}-{$dm[2]}-{$dm[1]}";
            }

            // Date filter removed — BHC uploads are irregular due to holidays/weekends.
            // Deduplication is handled by case_hash in wp_cl_mhc_cases table.

            // Tax keyword filter — word boundary for short abbrevs
            // Prevents CIT matching CITIZENS/CITY/ELECTRICITY etc.
            $is_tax = false;
            foreach ($tax_kws as $kw) {
                if (strlen($kw) <= 5) {
                    if (preg_match('/\b' . preg_quote($kw, '/') . '\b/', $party_text)) { $is_tax = true; break; }
                } else {
                    if (strpos($party_text, $kw) !== false) { $is_tax = true; break; }
                }
            }
            if (!$is_tax) continue;

            // Extract bhcpar from raw HTML (handles URL-encoded % values)
            if (!preg_match('/bhcpar=([A-Za-z0-9+\/=%]+)/', $row, $bm)) continue;
            $bhcpar_enc = $bm[1];
            $bhcpar = strpos($bhcpar_enc, '%') !== false ? urldecode($bhcpar_enc) : $bhcpar_enc;

            // Decode bhcpar to get fname and ncitation
            $decoded = base64_decode($bhcpar);
            if (!$decoded) continue;
            parse_str($decoded, $params);
            $fname = $params['fname']    ?? '';
            $ncit  = $params['ncitation']?? '';
            if (empty($fname)) continue;

            // Determine correct download endpoint
            $endpoint = (strpos($row, 'generatenewauth') !== false) ? 'generatenewauth' : 'generatepdf';

            // Matter number from col 1 (strip bench name suffix)
            $matter_raw = preg_replace('/\s+(NAGPUR|BOMBAY|KOLHAPUR|A\'BAD|GOA|AURANGABAD)[^$]*/i', '', $cols[1] ?? '');
            $matter_no  = trim($matter_raw);

            // Case title from party names
            $title = strlen($cols[2]) > 5 ? $cols[2] : ($ncit ?: "BHC {$case_date}");
            $title = substr(trim($title), 0, 500);

            // Bench detection from ncitation
            $bench = 'Bombay HC';
            if ($ncit) {
                if      (strpos($ncit,'BHC-AS') !==false) $bench='BHC Appellate Side';
                elseif  (strpos($ncit,'BHC-OS') !==false) $bench='BHC Original Side';
                elseif  (strpos($ncit,'BHC-NAG')!==false) $bench='BHC Nagpur';
                elseif  (strpos($ncit,'BHC-AUG')!==false) $bench='BHC Aurangabad';
                elseif  (strpos($ncit,'BHC-KOL')!==false) $bench='BHC Kolhapur';
                elseif  (strpos($ncit,'BHC-GOA')!==false) $bench='BHC Goa';
            }

            $category = $this->detect_category($party_text, $cat_map);

            $cases[] = array(
                'title'        => $title,
                'case_number'  => $ncit ?: $matter_no,
                'diary_number' => $fname,
                'category'     => $category,
                'cl_date'      => $case_date,
                'bhcpar'       => $bhcpar,
                'download_url' => "https://bombayhighcourt.nic.in/{$endpoint}.php?bhcpar=".urlencode($bhcpar),
                'bench'        => $bench,
                'fname'        => $fname,
                'matter_no'    => $matter_no,
            );
        }

        // Deduplicate by fname (same PDF sometimes listed under multiple matter numbers)
        $seen=array(); $unique=array();
        foreach ($cases as $c) {
            $key = $c['fname'];
            if (!isset($seen[$key])){$seen[$key]=true;$unique[]=$c;}
        }

        return $unique;
    }

    private function mhc_download_pdf($case) {
        $url = $case['download_url'] ?? '';
        if (empty($url)) {
            $this->log('MHC','error','download','No download_url in case array');
            return false;
        }

        $this->log('MHC','info','download',"Attempting: {$url}");

        // Try 1: ScraperAPI with binary mode
        // ScraperAPI supports binary downloads via &binary=true parameter
        $scraperapi_key = get_option('cl_scraperapi_key','');
        if (!empty($scraperapi_key)) {
            $api_url = 'http://api.scraperapi.com/?api_key='.urlencode($scraperapi_key)
                     . '&url='.urlencode($url)
                     . '&render=false'
                     . '&binary=true';  // tells ScraperAPI to return raw binary

            $resp = wp_remote_get($api_url, array(
                'timeout' => 90,
                'headers' => array('Accept' => 'application/pdf,*/*'),
            ));

            if (!is_wp_error($resp)) {
                $code = wp_remote_retrieve_response_code($resp);
                $body = wp_remote_retrieve_body($resp);
                $this->log('MHC','info','download',"ScraperAPI response: HTTP {$code}, ".strlen($body)." bytes, starts: ".substr($body,0,10));
                if ($code === 200 && strpos($body,'%PDF') === 0) {
                    return $body;
                }
            } else {
                $this->log('MHC','warn','download','ScraperAPI error: '.$resp->get_error_message());
            }
        }

        // Try 2: Direct download (works if server IP not blocked for this endpoint)
        $resp = wp_remote_get($url, array(
            'timeout' => 60,
            'headers' => array(
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer'    => 'https://bombayhighcourt.nic.in/recentorderjudgment.php',
                'Accept'     => 'application/pdf,*/*',
            ),
        ));

        if (is_wp_error($resp)) {
            $this->log('MHC','error','download','Direct: '.$resp->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $this->log('MHC','info','download',"Direct response: HTTP {$code}, ".strlen($body)." bytes, starts: ".substr($body,0,10));

        if ($code !== 200) {
            $this->log('MHC','warn','download',"Direct HTTP {$code}");
            return false;
        }

        if (strpos($body,'%PDF') !== 0) {
            $this->log('MHC','warn','download',"Not a PDF — first 100 bytes: ".substr($body,0,100));
            return false;
        }

        return $body;
    }

    // ── MHC: Process one case ─────────────────────────────────────────────────
    private function mhc_process_case($case, $hash) {
        global $wpdb;
        $ct = $wpdb->prefix.'cl_mhc_cases';

        $wpdb->insert($ct, array(
            'case_hash'   => $hash,
            'case_title'  => substr($case['title'],0,599),
            'case_number' => $case['case_number'],
            'diary_number'=> $case['diary_number'],
            'cl_date'     => $case['cl_date'],
            'tax_category'=> $case['category'],
            'status'      => 'pending',
        ));

        $pdf_content = $this->mhc_download_pdf($case);
        if (!$pdf_content) {
            $wpdb->update($ct,array('status'=>'no_pdf'),array('case_hash'=>$hash));
            return 'no_pdf';
        }

        $pdf_text = $this->extract_pdf_text($pdf_content);
        if (empty($pdf_text)||strlen($pdf_text)<200) {
            $this->log('MHC','warn','process',"PDF text extraction failed for {$case['title']}");
            $pdf_text='';
        }

        // GitHub path uses MHC/ prefix
        $this->log('MHC','info','process',"PDF OK (".strlen($pdf_content)." bytes). Uploading to GitHub...");
        $github_url = $this->upload_to_github($pdf_content,$case['title'],$case['category'],$case['cl_date'],'MHC');
        if (!$github_url) {
            $this->log('MHC','error','process',"GitHub upload FAILED for {$case['title']}. Check token/repo in Settings.");
            $wpdb->update($ct,array('pdf_url'=>$case['download_url'],'status'=>'github_failed'),array('case_hash'=>$hash));
            return false;
        }

        $this->log('MHC','info','process',"GitHub OK: {$github_url}");
        $summary = $this->generate_summary($case['title'],$case,$pdf_text,'Mumbai High Court');

        $this->log('MHC','info','process',"Creating WP post...");
        $post_id = $this->create_wp_post($case,$github_url,$summary,'MHC','Mumbai High Court');
        if (!$post_id) {
            $this->log('MHC','error','process',"WP post creation FAILED. Error: ".($wpdb->last_error?:'none'));
            $wpdb->update($ct,array('pdf_url'=>$case['download_url'],'github_url'=>$github_url,'status'=>'post_failed'),array('case_hash'=>$hash));
            return false;
        }

        $wpdb->update($ct,array(
            'pdf_url'    => $case['download_url'],
            'github_url' => $github_url,
            'post_id'    => $post_id,
            'status'     => 'completed',
        ),array('case_hash'=>$hash));

        $this->log('MHC','success','process',"Post #{$post_id}: {$case['title']}");
        return true;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SHARED UTILITIES
    // ══════════════════════════════════════════════════════════════════════════

    // ── PDF download (generic) ────────────────────────────────────────────────
    private function download_pdf($url, $court='SC') {
        $resp = wp_remote_get($url, array(
            'timeout' => 60,
            'headers' => array('User-Agent'=>'Mozilla/5.0 (compatible; WordPress/'.get_bloginfo('version').')'),
        ));
        if (is_wp_error($resp)) {
            $this->log($court,'error','download',$resp->get_error_message()." — {$url}");
            return false;
        }
        $code=wp_remote_retrieve_response_code($resp);
        if ($code!==200) {
            $this->log($court,'warn','download',"HTTP {$code} — {$url}");
            return false;
        }
        $body=wp_remote_retrieve_body($resp);
        if (strpos($body,'%PDF')!==0) {
            $this->log($court,'warn','download',"Not a valid PDF — {$url}");
            return false;
        }
        return $body;
    }

    // ── PDF text extraction ───────────────────────────────────────────────────
    private function extract_pdf_text($pdf_binary) {
        $tmp=sys_get_temp_dir().'/cl_'.uniqid().'.pdf';
        file_put_contents($tmp,$pdf_binary);

        if (function_exists('shell_exec')&&!in_array('shell_exec',array_map('trim',explode(',',ini_get('disable_functions'))))) {
            $pdftotext=trim(shell_exec('which pdftotext 2>/dev/null'));
            if (!empty($pdftotext)) {
                $out=$tmp.'.txt';
                shell_exec("{$pdftotext} -layout -enc UTF-8 {$tmp} {$out} 2>/dev/null");
                if (file_exists($out)) {
                    $text=file_get_contents($out);
                    @unlink($out);@unlink($tmp);
                    if (!empty($text)) return $text;
                }
            }
        }

        $text=$this->extract_pdf_text_regex($pdf_binary);
        @unlink($tmp);
        return $text;
    }

    private function extract_pdf_text_regex($pdf) {
        $text='';
        if (preg_match_all('/BT\s*(.*?)\s*ET/s',$pdf,$bt)) {
            foreach ($bt[1] as $b) {
                if (preg_match_all('/\[(.*?)\]\s*TJ/s',$b,$tj)) {
                    foreach ($tj[1] as $t) {
                        preg_match_all('/\(([^)]*)\)/',$t,$strings);
                        foreach ($strings[1] as $s) $text.=$this->decode_pdf_string($s);
                    }
                }
                if (preg_match_all('/\(([^)]*)\)\s*Tj/',$b,$tj2)) {
                    foreach ($tj2[1] as $s) $text.=$this->decode_pdf_string($s).' ';
                }
            }
        }
        if (strlen($text)<500) {
            preg_match_all('/\(([A-Z][A-Z\s\/\.,0-9\-]{5,100})\)/',$pdf,$plain);
            foreach ($plain[1] as $p) $text.=$p."\n";
        }
        return trim($text);
    }

    private function decode_pdf_string($s) {
        return str_replace(array('\\n','\\r','\\t','\\(','\\)','\\\\'),array("\n","\r","\t",'(',')',"\\"),$s);
    }

    // ── GitHub upload ─────────────────────────────────────────────────────────
    /**
     * Uploads PDF to GitHub.
     * Court prefix determines folder: SC/ or MHC/ or DHC/ etc.
     * Full path: {court_prefix}/YYYY/MM/Tax-Category/Case-Title.pdf
     */
    private function upload_to_github($content, $title, $category, $cl_date, $court_prefix='SC') {
        $token=get_option('cl_github_token');
        $owner=get_option('cl_github_owner');
        $repo =get_option('cl_github_repo');
        if (empty($token)||empty($owner)||empty($repo)) return false;

        $year  = $cl_date ? substr($cl_date,0,4) : date('Y');
        $month = $cl_date ? substr($cl_date,5,2) : date('m');
        $file  = sanitize_file_name($title).'.pdf';
        $cat_slug = sanitize_file_name($category);

        // Court prefix maps to folders
        $prefix_map = array(
            'SC'  => 'SC',
            'MHC' => 'MHC',
            'DHC' => 'DHC',
            'CHC' => 'CHC',
            'KHC' => 'KHC',
        );
        $folder = $prefix_map[$court_prefix] ?? strtoupper($court_prefix);
        $path   = "{$folder}/{$year}/{$month}/{$cat_slug}/{$file}";
        $api    = "https://api.github.com/repos/{$owner}/{$repo}/contents/{$path}";

        $check=wp_remote_get($api,array('headers'=>array('Authorization'=>'token '.$token,'User-Agent'=>'Court-Listener')));
        if (!is_wp_error($check)&&wp_remote_retrieve_response_code($check)===200) {
            $ex=json_decode(wp_remote_retrieve_body($check),true);
            return $ex['download_url']??false;
        }

        $resp=wp_remote_request($api,array(
            'method' =>'PUT',
            'timeout'=>60,
            'headers'=>array('Authorization'=>'token '.$token,'Content-Type'=>'application/json','User-Agent'=>'Court-Listener'),
            'body'   =>json_encode(array('message'=>"Add {$file}",'content'=>base64_encode($content))),
        ));

        if (is_wp_error($resp)) return false;
        $body=json_decode(wp_remote_retrieve_body($resp),true);
        return $body['content']['download_url']??false;
    }

    // ── Claude AI summary ─────────────────────────────────────────────────────
    private function generate_summary($title, $case, $pdf_text, $court_name='Supreme Court of India') {
        $api_key=get_option('cl_claude_key');
        if (empty($api_key)||empty($pdf_text)) return $this->fallback_summary($case,$court_name);

        $prompt="You are a senior Indian tax lawyer. Analyze this {$court_name} judgment and produce a concise structured summary in clean HTML (no markdown, no preamble).\n\n"
            ."Case: {$title}\n"
            ."Court: {$court_name}\n"
            ."Tax Area: {$case['category']}\n"
            ."Case Number: {$case['case_number']}\n\n"
            ."Excerpt from judgment:\n".substr($pdf_text,0,3000)."\n\n"
            ."Produce ONLY this HTML, nothing else:\n"
            ."<div class='cl-summary'>"
            ."<p><strong>Court:</strong> {$court_name}</p>"
            ."<p><strong>Tax Area:</strong> {$case['category']}</p>"
            ."<p><strong>Case Number:</strong> {$case['case_number']}</p>"
            ."<p><strong>Issue:</strong> [1-2 sentence legal question]</p>"
            ."<p><strong>Held:</strong> [Court's decision in 2-3 sentences]</p>"
            ."<p><strong>Key Sections:</strong> [Relevant statutory provisions, comma-separated]</p>"
            ."<p><strong>Implication:</strong> [Practical impact for taxpayers in 2 sentences]</p>"
            ."</div>";

        $resp=wp_remote_post('https://api.anthropic.com/v1/messages',array(
            'timeout'=>30,
            'headers'=>array(
                'x-api-key'         =>$api_key,
                'anthropic-version' =>'2023-06-01',
                'Content-Type'      =>'application/json',
            ),
            'body'=>json_encode(array(
                'model'     =>'claude-haiku-4-5-20251001',
                'max_tokens'=>700,
                'messages'  =>array(array('role'=>'user','content'=>$prompt)),
            )),
        ));

        if (!is_wp_error($resp)) {
            $body=json_decode(wp_remote_retrieve_body($resp),true);
            if (!empty($body['content'][0]['text'])) return wp_kses_post($body['content'][0]['text']);
        }

        return $this->fallback_summary($case,$court_name);
    }

    private function fallback_summary($case, $court_name='Court') {
        return "<div class='cl-summary'>"
            ."<p><strong>Court:</strong> ".esc_html($court_name)."</p>"
            ."<p><strong>Tax Area:</strong> ".esc_html($case['category'])."</p>"
            ."<p><strong>Case Number:</strong> ".esc_html($case['case_number'])."</p>"
            ."<p>This judgment was identified as a {$case['category']} matter. Review the full PDF for details.</p>"
            ."</div>";
    }

    // ── WordPress post creation (RevTheme-safe, raw $wpdb) ────────────────────
    /**
     * @param array  $case         Case data array
     * @param string $github_url   PDF download URL
     * @param string $summary      HTML summary from Claude
     * @param string $court_code   'SC' or 'MHC'
     * @param string $court_name   Full court name for display
     */
    private function create_wp_post($case, $github_url, $summary, $court_code, $court_name) {
        global $wpdb;

        $title  = wp_strip_all_tags($case['title']);
        $status = get_option('cl_auto_publish','draft');
        $now    = current_time('mysql');
        $now_g  = current_time('mysql',true);
        $slug   = sanitize_title($title);

        $content  = "<h2>Judgment Summary</h2>\n{$summary}\n\n";
        $content .= "<h2>Official Judgment PDF</h2>\n";
        $content .= '<p><a href="'.esc_url($github_url).'" class="button button-primary" target="_blank" rel="noopener">📄 Download Full PDF</a></p>';
        $content .= "\n<p style='font-size:12px;color:#888'>Court: ".esc_html($court_name)." | Date: ".esc_html($case['cl_date'])." | Case: ".esc_html($case['case_number'])."</p>";

        $wpdb->insert($wpdb->posts, array(
            'post_author'           => 1,
            'post_date'             => $now,
            'post_date_gmt'         => $now_g,
            'post_content'          => wp_kses_post($content),
            'post_title'            => $title,
            'post_excerpt'          => wp_trim_words($court_name.' — '.$case['category'].': '.$title, 25),
            'post_status'           => $status,
            'post_name'             => $slug,
            'post_modified'         => $now,
            'post_modified_gmt'     => $now_g,
            'post_type'             => 'cl_judgment',
            'to_ping'               => '',
            'pinged'                => '',
            'post_content_filtered' => '',
        ));

        $post_id=(int)$wpdb->insert_id;
        if (!$post_id) return false;

        // Post meta
        foreach (array(
            'cl_pdf_url'     => $github_url,
            'cl_case_number' => $case['case_number'],
            'cl_diary_number'=> $case['diary_number'],
            'cl_tax_category'=> $case['category'],
            'cl_court_code'  => $court_code,
            'cl_court_name'  => $court_name,
            'cl_case_date'   => $case['cl_date'],
        ) as $k=>$v) {
            $wpdb->insert($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>$k,'meta_value'=>$v));
        }

        // Taxonomies
        wp_set_object_terms($post_id,$court_name,'cl_court');
        wp_set_object_terms($post_id,$case['category'],'cl_tax_area');

        // RevTheme SEO meta
        $seo_title=substr($title.' — '.$court_name.' '.$case['category'].' Judgment',0,60);
        $seo_desc =substr($court_name.' judgment on '.$case['category'].': '.$title.' Case: '.$case['case_number'],0,160);
        $wpdb->insert($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>'_rev_seo_title','meta_value'=>$seo_title));
        $wpdb->insert($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>'_rev_meta_description','meta_value'=>$seo_desc));
        $wpdb->insert($wpdb->postmeta,array('post_id'=>$post_id,'meta_key'=>'_rev_focus_keyword','meta_value'=>$case['category']));

        clean_post_cache($post_id);
        return $post_id;
    }

    // ── Tax category detection ────────────────────────────────────────────────
    private function detect_category($text, $cat_map) {
        $upper=strtoupper($text);
        foreach ($cat_map as $cat=>$keywords) {
            foreach ($keywords as $kw) {
                if (strlen($kw) <= 5) {
                    // Word boundary: CIT must not match CITIZENS/CITY/ELECTRICITY
                    if (preg_match('/\b' . preg_quote($kw, '/') . '\b/', $upper)) return $cat;
                } else {
                    if (strpos($upper,$kw)!==false) return $cat;
                }
            }
        }
        return 'Income Tax';
    }

    // ── Deduplication check ───────────────────────────────────────────────────
    private function is_processed($court_code, $hash) {
        global $wpdb;
        $table = $wpdb->prefix.'cl_'.strtolower($court_code).'_cases';
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE case_hash=%s", $hash
        )) > 0;
    }


    // ── Proxy-aware HTTP GET ──────────────────────────────────────────────────
    /**
     * Wraps wp_remote_get with optional ScraperAPI or HTTP proxy routing.
     * Used for all NIC government site requests which block datacenter IPs.
     *
     * Priority: ScraperAPI key > proxy_url > direct connection
     */
    private function proxy_get($url, $args=array()) {
        $scraperapi_key = get_option('cl_scraperapi_key','');
        $proxy_url      = get_option('cl_proxy_url','');

        if (!empty($scraperapi_key)) {
            // Route through ScraperAPI — they handle residential IP rotation
            $api_url = 'http://api.scraperapi.com/?api_key='.urlencode($scraperapi_key).'&url='.urlencode($url).'&render=false';
            // ScraperAPI needs a longer timeout (they fetch + return)
            $args['timeout'] = max($args['timeout']??30, 60);
            return wp_remote_get($api_url, $args);
        }

        if (!empty($proxy_url)) {
            // Use configured HTTP proxy
            $args['proxy'] = $proxy_url;
            return wp_remote_get($url, $args);
        }

        // Direct — will timeout on Cloudways if NIC is blocking
        return wp_remote_get($url, $args);
    }

    // ── Logger ────────────────────────────────────────────────────────────────
    private function log($court, $level, $context, $message) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'cl_logs',array(
            'court'  => $court,
            'level'  => $level,
            'context'=> $context,
            'message'=> substr($message,0,1000),
        ));
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SHORTCODES
    // ══════════════════════════════════════════════════════════════════════════

    public function shortcode_all($atts) {
        $atts=shortcode_atts(array('per_page'=>10,'category'=>'','court'=>''),$atts);
        return $this->render_judgment_listing($atts);
    }

    public function shortcode_sc($atts) {
        $atts=shortcode_atts(array('per_page'=>10,'category'=>''),$atts);
        $atts['court']='Supreme Court of India';
        return $this->render_judgment_listing($atts);
    }

    public function shortcode_mhc($atts) {
        $atts=shortcode_atts(array('per_page'=>10,'category'=>''),$atts);
        $atts['court']='Mumbai High Court';
        return $this->render_judgment_listing($atts);
    }

    private function render_judgment_listing($atts) {
        ob_start();
        $s=sanitize_text_field(get_query_var('s'));
        $args=array('post_type'=>'cl_judgment','posts_per_page'=>(int)$atts['per_page'],'post_status'=>'publish');
        if ($s) $args['s']=$s;

        $tax_query=array('relation'=>'AND');
        if (!empty($atts['category'])) {
            $tax_query[]=array('taxonomy'=>'cl_tax_area','field'=>'name','terms'=>$atts['category']);
        }
        if (!empty($atts['court'])) {
            $tax_query[]=array('taxonomy'=>'cl_court','field'=>'name','terms'=>$atts['court']);
        }
        if (count($tax_query)>1) $args['tax_query']=$tax_query;

        $q=new WP_Query($args);
        ?>
        <div style="max-width:1100px;margin:0 auto">
        <form method="get" style="background:#f8f9fa;padding:16px;border-radius:8px;margin-bottom:22px">
            <input type="text" name="s" placeholder="Search judgments (income tax, GST, section 148…)"
                   value="<?php echo esc_attr($s) ?>"
                   style="width:100%;padding:11px;border:1px solid #ddd;border-radius:4px;font-size:15px"/>
            <button type="submit" style="margin-top:8px;padding:9px 20px;background:#0073aa;color:#fff;border:none;border-radius:4px;font-size:14px;cursor:pointer">🔍 Search</button>
        </form>
        <?php if ($q->have_posts()): ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px">
        <?php while ($q->have_posts()): $q->the_post();
            $pdf   = get_post_meta(get_the_ID(),'cl_pdf_url',true);
            $cat   = get_post_meta(get_the_ID(),'cl_tax_category',true);
            $cn    = get_post_meta(get_the_ID(),'cl_case_number',true);
            $court = get_post_meta(get_the_ID(),'cl_court_name',true);
        ?>
        <div style="background:#fff;border:1px solid #e0e0e0;border-left:4px solid #0073aa;border-radius:8px;padding:16px">
            <p style="margin:0 0 4px;font-size:11px;color:#888;text-transform:uppercase"><?php echo esc_html($court) ?> | <?php echo esc_html($cat) ?></p>
            <p style="margin:0 0 4px;font-size:11px;color:#aaa"><?php echo esc_html($cn) ?></p>
            <h3 style="margin:0 0 8px;font-size:15px"><a href="<?php the_permalink() ?>" style="color:#2c3e50;text-decoration:none"><?php the_title() ?></a></h3>
            <p style="color:#555;font-size:13px;line-height:1.6"><?php echo wp_trim_words(get_the_excerpt(),20) ?></p>
            <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
                <a href="<?php the_permalink() ?>" style="background:#0073aa;color:#fff;padding:6px 12px;text-decoration:none;border-radius:4px;font-size:12px">Read Analysis</a>
                <?php if ($pdf): ?><a href="<?php echo esc_url($pdf) ?>" target="_blank" rel="noopener" style="background:#28a745;color:#fff;padding:6px 12px;text-decoration:none;border-radius:4px;font-size:12px">📄 PDF</a><?php endif ?>
            </div>
        </div>
        <?php endwhile; echo '</div>';
        echo '<div style="margin-top:20px;text-align:center">'.paginate_links().'</div>';
        else: ?>
        <p style="text-align:center;padding:36px;background:#fff;border-radius:8px;color:#666">No judgments found. Try a different search term.</p>
        <?php endif; wp_reset_postdata(); ?>
        </div>
        <?php
        return ob_get_clean();
    }

} // end class Court_Listener
